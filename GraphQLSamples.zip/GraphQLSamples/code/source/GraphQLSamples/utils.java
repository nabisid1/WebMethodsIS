package GraphQLSamples;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.*;
import com.wm.app.b2b.server.*;
import com.wm.util.coder.*;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void getKeys (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getKeys)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:1:required Keys
	// get cursor on pipeline
	IDataCursor idcPipeline = pipeline.getCursor();

	// initialize variables
	Enumeration keys = null;
	Vector v = new Vector();

	// check to see if properties object is null
	if (properties == null)
	{
		loadProperties( null );
	}

	// get key names from properties object
	keys = properties.propertyNames();

	// build a vector of the keys
	while (keys.hasMoreElements())
	{
		String id = (String) keys.nextElement();
		v.addElement(id);
	}

	// put the keys in a string list
    int idCount = v.size();
	if (idCount >0)
	{
		String[] astrKeys = new String[idCount];
		v.copyInto(astrKeys);

		// Put data into pipeline
		idcPipeline.insertAfter("Keys", astrKeys);
	}


	// always destroy your cursor
	idcPipeline.destroy();
	
		// --- <<IS-END>> ---

                
	}



	public static final void getProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getProperties)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required Keys
		// [o] record:0:required Properties
		// get Cursor on pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		// Initialize variables
		String[] strKey   = null;
		String   strValue = null;
		int i;
		IData id = IDataFactory.create();
		IDataCursor idc = id.getCursor();
		
		// Get data from pipeline
		if ( pipelineCursor.first( "Keys" ) )
		{
		 	strKey = (String[]) pipelineCursor.getValue();
		}
		else
		{
			// Input not found
			
			return;
		}
		
		// loop over the keys and get the property values
		for (i = 0; i < strKey.length; i++)
		{
			// Get property from memory
			strValue = getProperty(strKey[i]);
			
		
			// insert the key and value into the IData object
			idc.insertAfter(strKey[i], strValue);
		}
		 
		// Put output into pipeline
		pipelineCursor.last();
		pipelineCursor.insertAfter( "Properties", id );
		
		// Always destroy your cursor
		pipelineCursor.destroy();
		idc.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void loadProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(loadProperties)>> ---
		// @subtype unknown
		// @sigtype java 3.5
    /*
        Retrieves values from configuration file named "yourCustomConfig.cnf" from
        directory [server]/packages/WmSamples/config
    */

	// build the location of the config file
    String configFile = "packages" + File.separator + PACKAGE + File.separator +
                        "config" + File.separator + CONFIG_FILE;


    try
	{
		// read in the file stream and convert it to a properties object
        FileInputStream configFileInputStream = new FileInputStream( configFile );

		// properties object is already defined in the Shared code
        properties = new Properties();
        properties.load( configFileInputStream );
		propertiesLoaded = true;

      
    	    }
	catch ( FileNotFoundException e )
	{
        // print error to standard out and throw an error
   
		Service.throwError("Error finding property file: "+e);
    }
	catch ( IOException e )
	{
        // print error to standard out and throw an error
 
	Service.throwError("Error reading configuration.properties property file: "+e);
    }
	
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	// initialize static variables
	private static String PACKAGE = "GraphQLSamples";
	private static String CONFIG_FILE ="configuration.properties";
 
    private static boolean propertiesLoaded = false;
    private static Properties properties = null;
    
    
    /** gets a property from the config file **/
    public static String getProperty( String key )
    {
		// check to see if the properties have been loaded
        if (!propertiesLoaded) {
			try
			{
				
            	loadProperties( null );
			}
			catch (Exception e)
			{
            //    try {
            
              //  } catch (ServiceException eee) { /* ignore */ }
			}
        }
        if ( properties == null )
            return( null );
        else
            return( properties.getProperty( key ) );
    }
	
	// --- <<IS-END-SHARED>> ---
}

