package InfraMon.services.monitor.is;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-04-04 14:43:06 CEST
// -----( ON-HOST: rboshuis-1.InfraMon.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ACLManager;
// --- <<IS-END-IMPORTS>> ---

public final class startup

{
	// ---( internal utility methods )---

	final static startup _instance = new startup();

	static startup _newInstance() { return new startup(); }

	static startup _cast(Object o) { return (startup)o; }

	// ---( server methods )---




	public static final void setExecACL (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(setExecACL)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required nsname
		// [i] field:0:required aclGroup
		IDataCursor pc = pipeline.getCursor();
		String nsname = IDataUtil.getString(pc, "nsname"); 
		String group  = IDataUtil.getString(pc, "aclGroup"); 
		ACLManager.setAclGroup(nsname, group); 
		pc.destroy();
		
		/**
		 * @param nsname -- The full namespace of the folder or component
		 * @param aclGroup -- A valid IS user group name to grant access to  **/
		
		// --- <<IS-END>> ---

                
	}
}

