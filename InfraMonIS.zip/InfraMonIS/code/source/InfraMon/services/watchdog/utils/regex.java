package InfraMon.services.watchdog.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-09-28 11:30:25 CEST
// -----( ON-HOST: hpx96

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.ArrayList;
// --- <<IS-END-IMPORTS>> ---

public final class regex

{
	// ---( internal utility methods )---

	final static regex _instance = new regex();

	static regex _newInstance() { return new regex(); }

	static regex _cast(Object o) { return (regex)o; }

	// ---( server methods )---




	public static final void match (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(match)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required pattern
		// [i] field:0:required string
		// [o] field:0:required matched
		// [o] field:1:required matches
		IDataCursor pc = pipeline.getCursor();
		String regex = IDataUtil.getString(pc, "pattern");
		String string = IDataUtil.getString(pc, "string");
		
		ArrayList list = new ArrayList();
		if (regex != null && string != null) {
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(string);
			while (matcher.find()) {
				list.add(matcher.group());
			}
		}
		
		IDataUtil.put(pc, "matches", (String[])list.toArray(new String[0]));
		IDataUtil.put(pc, "matched", String.valueOf(list.size() > 0));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}
}

