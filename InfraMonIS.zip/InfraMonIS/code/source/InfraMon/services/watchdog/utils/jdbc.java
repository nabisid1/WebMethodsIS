package InfraMon.services.watchdog.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-09-28 10:25:38 CEST
// -----( ON-HOST: hpx96

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.sql.*;
import java.util.*;
import com.wm.app.b2b.server.*;
import java.text.*;
// --- <<IS-END-IMPORTS>> ---

public final class jdbc

{
	// ---( internal utility methods )---

	final static jdbc _instance = new jdbc();

	static jdbc _newInstance() { return new jdbc(); }

	static jdbc _cast(Object o) { return (jdbc)o; }

	// ---( server methods )---




	public static final void queryWmDatabase (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(queryWmDatabase)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required alias
		// [i] field:0:required sql
		// [o] field:0:required rowcount
		// [o] record:1:required results
		IDataCursor pc = pipeline.getCursor();
		String sql = IDataUtil.getString(pc, "sql");
		String alias = IDataUtil.getString(pc, "alias");
		
		IData[] results = __execSQL(sql, alias);
		IDataUtil.put(pc, "results", results);
		IDataUtil.put(pc, "rowcount", String.valueOf(results.length));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static Connection __getConnection(String alias) throws Exception {
		return JDBCConnectionManager.getConnection(alias);
	}
	
	public static void __releaseConnection(String alias, Connection conn) throws ServiceException {
		try {
			JDBCConnectionManager.releaseConnection(alias, conn);
		} catch (Exception e) {
			throw new ServiceException("Cannot return connection to pool '" + alias + "' -- " + e.toString());
		}
	}
	
	public static IData[] __execSQL(String sql, String alias) throws ServiceException {
	
		// Get connection
	    Connection conn = null;
	    try {
			conn = __getConnection(alias);
		} catch (Exception e) {
			throw new ServiceException("Cannot obtain connection from pool '" + alias + "' -- " + e.toString());
		}
		
		ResultSet result = null;
		Statement stmt = null;
		try {
	        stmt = conn.createStatement();
	        result = stmt.executeQuery(sql);
		} catch (Exception e) {
			if (conn != null) {
				__releaseConnection(alias, conn);
			}
			throw new ServiceException("Cannot obtain result set for '" + sql + "' -- " + e.toString());
		}
	
		ArrayList records = new ArrayList();
		try {
	        while (result.next()) {
	            ResultSetMetaData rsmd = result.getMetaData();
	
				IData record = IDataFactory.create();
	            IDataCursor rc = record.getCursor();
	
	            int cols = rsmd.getColumnCount();
	            for (int i = 1; i <= cols; i++) {
					IDataUtil.put(rc, rsmd.getColumnLabel(i), result.getString(i));
				}
	            rc.destroy();
	            records.add(record);
			}
	        stmt.close();
		} catch (Exception e) {
			throw new ServiceException("Could not get data with '" + sql + "'.\n" + e.toString());
		} finally {
			if (conn != null) {
				__releaseConnection(alias, conn);
			}
		}
	    return (IData[])records.toArray(new IData[0]);
	}
	// --- <<IS-END-SHARED>> ---
}

