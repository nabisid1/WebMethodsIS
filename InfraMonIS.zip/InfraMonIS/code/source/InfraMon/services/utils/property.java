package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-06-26 14:04:01 MEST
// -----( ON-HOST: itsbex05

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
import com.wm.app.b2b.server.*;
import com.wm.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class property

{
	// ---( internal utility methods )---

	final static property _instance = new property();

	static property _newInstance() { return new property(); }

	static property _cast(Object o) { return (property)o; }

	// ---( server methods )---




	public static final void getSpecificSystemProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSpecificSystemProperties)>> ---
		// @sigtype java 3.5
		
		IDataCursor idcPipeline = pipeline.getCursor();
		
		IData systemProperties = IDataFactory.create();
		IDataCursor idcSystemProperties = systemProperties.getCursor();
		
		idcSystemProperties.insertAfter("java.version", System.getProperty("java.version"));
		idcSystemProperties.insertAfter("java.vendor", System.getProperty("java.vendor"));
		idcSystemProperties.insertAfter("java.vendor.url", System.getProperty("java.vendor.url"));
		idcSystemProperties.insertAfter("java.home", System.getProperty("java.home"));
		idcSystemProperties.insertAfter("java.class.version", System.getProperty("java.class.version"));
		idcSystemProperties.insertAfter("java.class.path", System.getProperty("java.class.path"));
		idcSystemProperties.insertAfter("os.name", System.getProperty("os.name"));
		idcSystemProperties.insertAfter("os.arch", System.getProperty("os.arch"));
		idcSystemProperties.insertAfter("os.version", System.getProperty("os.version"));
		idcSystemProperties.insertAfter("file.separator", System.getProperty("file.separator"));
		idcSystemProperties.insertAfter("path.separator", System.getProperty("path.separator"));
		idcSystemProperties.insertAfter("line.separator", System.getProperty("line.separator"));
		idcSystemProperties.insertAfter("user.name", System.getProperty("user.name"));
		idcSystemProperties.insertAfter("user.home", System.getProperty("user.home"));
		idcSystemProperties.insertAfter("user.dir", System.getProperty("user.dir"));
		
		idcPipeline.insertAfter("SystemProperties", systemProperties);
		
		idcSystemProperties.destroy();
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getSystemProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSystemProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		// [o] field:0:required property
		/** Service is designed to return the specified system property.
		  *
		  * @author Ryan Johnston, Professional Services, webMethods, Inc.
		  * @version 1.0
		  * Modified to check for existing of propertyList before delete (Ronald B)
		  */
		
		IDataCursor hCursor = pipeline.getCursor();
		
		hCursor.first("propertyName");
		String propertyName = (String)hCursor.getValue();
		
		String property = new String();
		
		property = System.getProperty(propertyName, "No property found");
		
		if (hCursor.first("property"))
			hCursor.delete();
		hCursor.insertAfter("property", property);
		
		hCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

