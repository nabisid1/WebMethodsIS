package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-06-25 08:49:20 MEST
// -----( ON-HOST: itsbex05

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import com.wm.data.*;
import com.wm.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class stream

{
	// ---( internal utility methods )---

	final static stream _instance = new stream();

	static stream _newInstance() { return new stream(); }

	static stream _cast(Object o) { return (stream)o; }

	// ---( server methods )---




	public static final void bytesToStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(bytesToStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required buffer
		// [i] field:0:required length
		// [o] object:0:required blockStream
		IDataCursor cursor = pipeline.getCursor();
		
		byte[] buff = null;
		int len;
		ByteArrayInputStream blockStream = null;
		
		if (cursor.first("buffer"))
		{
		  buff = (byte[]) cursor.getValue();
		}
		else
		{
		  throw new ServiceException("Input parameter \'buffer\' was not found.");
		}
		if (cursor.first("length"))
		{
		  len = Integer.parseInt((String) cursor.getValue());
		}
		else
		{
		  throw new ServiceException("Input parameter \'length\' was not found.");
		}
		cursor.destroy();
		
		if (buff != null)
		{
		  blockStream = new ByteArrayInputStream(buff, 0, len);
		}
		// else, no-op;
		
		cursor = pipeline.getCursor();
		cursor.last();
		cursor.insertAfter("blockStream", blockStream);
		cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void closeStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(closeStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required stream
		// [o] field:0:required message
		
		// Global declarations
		String message = null;
		
		// get inputs
		IDataCursor idcPipeline = pipeline.getCursor();
		
		if (idcPipeline.first("stream"))
		{
		  Object stream = idcPipeline.getValue();
		
		  // The code below can be easily modified to handle Readers as well
		  try
		  {
		    String className = stream.getClass().getName();
		
		    if (className.endsWith("InputStream"))
		    {
		      InputStream is = (InputStream) stream;
		      is.close();
		      message = "Input Stream closed successfully.";
		    }
		    else if (className.endsWith("OutputStream"))
		    {
		      OutputStream os = (OutputStream) stream;
		      os.close();
		      message = "Output Stream closed successfully.";
		    }
		  }
		  catch (Exception e)
		  {
		    throw new ServiceException(e.toString());
		  }
		}
		else
		{
		  throw new ServiceException("Input stream not found");
		}
		
		// outputs
		idcPipeline.last();
		idcPipeline.insertAfter("message", message);
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void stringToStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringToStream)>> ---
		// @sigtype java 3.5
		// [i] field:0:required string
		// [o] object:0:required stream
		
		IDataCursor idcPipeline = pipeline.getCursor();
		
		idcPipeline.first("string");
		String string = (String) idcPipeline.getValue();
		
		StringBufferInputStream output = new StringBufferInputStream(string);
		
		while (idcPipeline.first("stream"))
		{
		  idcPipeline.delete();
		}
		
		idcPipeline.last();
		
		Object inputStream = output;
		
		idcPipeline.insertAfter("stream", inputStream);
		
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}
}

