package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-09-28 10:27:02 CEST
// -----( ON-HOST: hpx96

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import com.wm.util.coder.*;
import com.wm.data.*;
import com.wm.util.Debug;
import java.net.UnknownHostException;
import com.wm.app.b2b.server.*;
import java.util.Date;
import java.net.InetAddress;
import com.wm.lang.ns.NSName;
import java.text.*;
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class fileio

{
	// ---( internal utility methods )---

	final static fileio _instance = new fileio();

	static fileio _newInstance() { return new fileio(); }

	static fileio _cast(Object o) { return (fileio)o; }

	// ---( server methods )---




	public static final void createPath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createPath)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required pathName
		// [o] field:0:required resultPath
		// [o] field:0:required basePath
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	pathName = IDataUtil.getString( pipelineCursor, "pathName" );
		pipelineCursor.destroy();
		
		String resultPath = "";
		String basePath = "";
		
		// pipeline
		if ( pathName != null ) 
		{
			basePath = Server.getLogDir()+"/";
			resultPath = basePath + pathName + "/";
			new File( resultPath ).mkdirs();
		}
		
		// pipeline
		IDataCursor out_pipelineCursor = pipeline.getCursor();
		IDataUtil.put( out_pipelineCursor, "resultPath", resultPath );
		IDataUtil.put( out_pipelineCursor, "basePath", basePath );
		pipelineCursor.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void deleteFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required deleteStatus
		// [o] field:0:required length
	IDataCursor cursor = pipeline.getCursor();

	String filename = null;
	if (cursor.first("filename"))
	{
		filename = (String) cursor.getValue();
	}
	else
	{
		throw new ServiceException("Input parameter \'filename\' was not found.");
	}
	cursor.destroy();

	File file = new File(filename);
	long len = file.length();
	boolean b = file.delete();

	cursor = pipeline.getCursor();
	cursor.last();
	cursor.insertAfter("deleteStatus", "" + b);
	cursor.insertAfter("length", "" + len);
	cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getResourcesDir (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getResourcesDir)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] field:0:required dir
		IDataCursor pc = pipeline.getCursor();
		String packageName = IDataUtil.getString(pc, "packageName");
		
		String dir = ServerAPI.getServerConfigDir().getParent();
		try {
			dir = new java.io.File(dir).getCanonicalPath();
		} catch (Exception e) {}
		dir += File.separator + "packages" 
		     + File.separator + packageName
		     + File.separator + "resources" 
		     + File.separator;
		
		// Handle output results
		IDataUtil.put(pc, "dir", dir);
		pc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void isDirectory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isDirectory)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required path
		// [i] field:0:required createOnError
		// [i] field:0:required accessList
		// [o] field:0:required exists
		// [o] field:0:required isDirectory {"true","false"}
		IDataCursor pipelineCursor = pipeline.getCursor();
		String exists = "false";
		String isDirectory = "false";
		boolean create = false;
		String sPath  = IDataUtil.getString( pipelineCursor, "path" );
		String createOnError = IDataUtil.getString( pipelineCursor, "createOnError" );
		String accessList = IDataUtil.getString( pipelineCursor, "accessList" );
		
		if(createOnError != null && createOnError.equals("Y"))
		    create = true;
		 
		try
		{
			File fPath = new File(sPath);
		
		    if (fPath != null) {
		
				if(fPath.exists()) {
		           exists = "true";
		           if (fPath.isDirectory() )
		                isDirectory = "true";
		           
				}
		        else if (create && fPath.mkdirs()) {
		              exists = "true";
		              isDirectory = "true";
					  if ((isDirectory == "true") && (accessList != null)) {
							FileWriter fw = new FileWriter(sPath + ".access", false);
							fw.write("* "+accessList+"\n\r" );					
							fw.flush();
							fw.close();
					  }
				}
		
			}
		
		} 
		catch (Exception e)
		{
			exists = "false";
		}
		
		IDataUtil.put( pipelineCursor, "exists", exists);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		IDataCursor pipelineCursor = pipeline.getCursor();
		String sFile  = IDataUtil.getString( pipelineCursor, "file" );
		String exists = "false";
		
		try
		{
			File fFile = new File(sFile);
			if (fFile.isFile())
			{
				exists = "true";
			}
		}
		catch (Exception e) {}
		
		IDataUtil.put( pipelineCursor, "exists", exists);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void listDirEntries (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listDirEntries)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required path
		// [i] field:0:required createAccessList
		// [i] field:0:required accessList
		// [o] field:1:required directories
		// [o] field:1:required files
		IDataCursor pc = pipeline.getCursor();
		boolean create = false;
		String sPath  = IDataUtil.getString( pc, "path" );
		String createAccessList = IDataUtil.getString( pc, "createAccessList" );
		String accessList = IDataUtil.getString( pc, "accessList" );
		String [] dirEntries = null;
		ArrayList files = new ArrayList();
		ArrayList directories = new ArrayList();  
		
		if(createAccessList != null && createAccessList.equals("true"))
		    create = true;
		 
		try
		{
			File fPath = new File(sPath);
		
		    if (fPath != null) 
			if(fPath.exists()) 
		           if (fPath.isDirectory()) {
				if (create) {
					FileWriter fw = new FileWriter(sPath + "/.access", false);
					fw.write("* "+accessList+"\n\r" );					
					fw.flush();
					fw.close();
				}
				dirEntries = fPath.list();
				for (int i=0; i< dirEntries.length; i++) {
					File sub = new File(sPath + "/" + dirEntries[i]);
					if (sub.isDirectory()) {
						directories.add(dirEntries[i]);
					} else { 
						files.add(dirEntries[i]);
					}
				}
			   }
		} 
		catch (Exception e)
		{
		}
		
		IDataUtil.put(pc, "files", (String[])files.toArray(new String[0]));
		IDataUtil.put(pc, "directories", (String[])directories.toArray(new String[0]));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void readFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required path
		// [i] field:0:required mode {"string","stringlist","bytes","stream"}
		// [i] field:0:optional start
		// [i] field:0:optional length
		// [o] field:0:optional string
		// [o] field:1:optional stringlist
		// [o] object:0:optional bytes
		// [o] object:0:optional stream
		// [o] field:0:optional length
		IDataCursor pc = pipeline.getCursor();
		String path = IDataUtil.getString(pc, "path");
		String mode = IDataUtil.getString(pc, "mode");
		String start = IDataUtil.getString(pc, "start");
		String length = IDataUtil.getString(pc, "length");
		
		int strt = start != null ? new Integer(start).intValue() : 0;
		int len = length != null ? new Integer(length).intValue() : -1;
		
		boolean exists = false;
		try {
			exists = exists(path);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		
		if (path != null && exists) {
			try {
				if (mode.equals("string")) {
					String read = readString(path, strt, len);
					IDataUtil.put(pc, "string", read);
					IDataUtil.put(pc, "length", String.valueOf(read.length()));
				} else if (mode.equals("stringlist")) {	
					String[] read = readLines(path, strt, len);
					IDataUtil.put(pc, "stringlist", read);
					IDataUtil.put(pc, "length", String.valueOf(read.length));
				} else if (mode.equals("bytes")) {
					byte[] read = readBytes(path, strt, len);
					IDataUtil.put(pc, "bytes", read);
					IDataUtil.put(pc, "length", String.valueOf(read.length));
				} else {
					InputStream read = readStream(path);
					IDataUtil.put(pc, "stream", read);
					IDataUtil.put(pc, "length", String.valueOf(read.available()));
				}
			} catch (Exception e) {
				throw new ServiceException(e);
			}
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void writeFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required path
		// [i] field:0:required mode {"append","prepend","overwrite"}
		// [i] field:0:optional maxSize
		// [i] field:0:optional content
		// [i] object:0:optional bytes
		// [i] object:0:optional stream
		// [o] field:0:optional length
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		String path = IDataUtil.getString(pc, "path");
		String mode = IDataUtil.getString(pc, "mode");
		String maxSize = IDataUtil.getString(pc, "maxSize");
		
		String content = IDataUtil.getString(pc, "content");
		byte[] bytes = content != null ? content.getBytes() : (byte[])IDataUtil.get(pc, "bytes");
		InputStream stream = bytes != null ? new ByteArrayInputStream(bytes) : (InputStream)IDataUtil.get(pc, "stream");
		int size = maxSize != null ? new Integer(maxSize).intValue() * 1024 : -1;
		
		if (stream != null) {
			try {
				if (mode.equals("overwrite")) {
					IDataUtil.put(pc, "length", String.valueOf(writeOver(stream, path, size)));
				} else if (mode.equals("prepend")) {
					IDataUtil.put(pc, "length", String.valueOf(writeBefore(stream, path, size)));
				} else {
					IDataUtil.put(pc, "length", String.valueOf(writeAfter(stream, path, size)));
				}
			} catch (Exception e) {
				throw new ServiceException(e);
			}
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static boolean exists(String path)
		throws Exception {
		boolean exists = false;
		File file = new File(path);
		return file.exists() && (file.isFile() || file.isDirectory());
	}
	
	public static long writeAfter(InputStream stream, String path, int maxSize)
		throws Exception {
		return write(null, stream, path, true, maxSize);
	}
	
	public static long writeBefore(InputStream stream, String path, int maxSize)
		throws Exception {
		byte[] bytes = readBytes(path, 0, maxSize);
		return write(new ByteArrayInputStream(bytes), stream, path, false, maxSize);
	}
	
	public static long writeOver(InputStream stream, String path, int maxSize)
		throws Exception {
		return write(null, stream, path, false, maxSize);
	}
	
	public static long write(InputStream afterStream, InputStream beforeStream, String path, boolean append, int maxSize)
		throws Exception {
		if (!exists(getParent(path))) {
			throw new IOException();
		}
	
		FileOutputStream fout = new FileOutputStream(path, append);
		int pos = 0;
		int read = 0;
		byte[] buffer = new byte[8192];
		
		while ((read = beforeStream.read(buffer, 0, buffer.length)) > 0 && (pos < maxSize || maxSize == -1)) {
			fout.write(buffer, 0, read);
			pos += read;
		}
		beforeStream.close();
	
		int pos2 = pos;
		if (afterStream != null && afterStream.available() > 0) {
			while ((read = afterStream.read(buffer, 0, buffer.length)) > 0 && (pos2 < maxSize || maxSize == -1)) {
				fout.write(buffer, 0, read);
				pos2 += read;
			}
			afterStream.close();
		}
	
		fout.flush();
		fout.close();
		return pos;
	}
	
	public static String readString(String path, int start, int length)
		throws Exception {
		return new String(readBytes(path, start, length));
	}
	
	public static String[] readLines(String path, int start, int length)
		throws Exception {
		if (!exists(path)) {
			return new String[0];
		}
	
		ArrayList content = new ArrayList();
		BufferedReader in = new BufferedReader(new FileReader(path));
		String line = "";
		long ln = 0;
		while ((line = in.readLine()) != null) {
			if (ln >= start) {
				content.add(line);
				if (length > 0 && start + ln >= length) {
					break;
				}
			}
			ln++;
		}
		in.close();
		return (String[])content.toArray(new String[0]);
	}
	
	public static byte[] readBytes(String path, int start, int length)
		throws Exception {
		if (!exists(path)) {
			return new byte[0];
		}
	
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		FileInputStream fin = (FileInputStream)readStream(path);
		int pos = start;
		int read = 0;
		byte[] buffer = new byte[8192];
		while ((read = fin.read(buffer, 0, buffer.length)) > 0 && (pos < length || length == -1)) {
			bout.write(buffer, 0, read);
			pos += read;
		}
		bout.flush();
	
		byte[] bytes = bout.toByteArray();
		bout.close();
		return bytes;
	}
	
	public static InputStream readStream(String path)
		throws Exception {
		return new FileInputStream(path);
	}
	
	public static long size(String filename)
		throws Exception {
		return new File(filename).length();
	}
	
	public static String getName(String path)
		throws Exception {
		if (path.lastIndexOf(File.separator) >= 0) {
			path = path.substring(path.lastIndexOf(File.separator) + 1, path.length());
		}
		return path;
	}
	
	public static String getParent(String path)
		throws Exception {
		return new File(path).getParentFile().getCanonicalPath();
	}
	// --- <<IS-END-SHARED>> ---
}

