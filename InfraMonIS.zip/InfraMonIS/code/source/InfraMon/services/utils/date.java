package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-06-26 15:01:16 MEST
// -----( ON-HOST: itsbex05

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.*;
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class date

{
	// ---( internal utility methods )---

	final static date _instance = new date();

	static date _newInstance() { return new date(); }

	static date _cast(Object o) { return (date)o; }

	// ---( server methods )---




	public static final void calculateDateDifference (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(calculateDateDifference)>> ---
		// @sigtype java 3.5
		// [i] field:0:required startDateTime
		// [i] field:0:required endDateTime
		// [i] field:0:required startDateFormat
		// [i] field:0:required endDateFormat
		// [o] field:0:required dateDifferenceSec
		// [o] field:0:required dateDifferenceMin
		// [o] field:0:required dateDifferenceHr
		// [o] field:0:required dateDifferenceDay
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	startDateTime = "";
		String	endDateTime = "";
		String startDateFormat = "";
		String endDateFormat = "";
		if (pipelineCursor.first("startDateTime"))
		{
			startDateTime = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("endDateTime"))
		{
			endDateTime = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("startDateFormat"))
		{
			startDateFormat = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("endDateFormat"))
		{
			endDateFormat = (String) pipelineCursor.getValue();
		}
		
		if (startDateTime.equals("") || endDateTime.equals(""))
			throw new ServiceException("Dates cannot be null");
		if (startDateFormat.equals("") || endDateFormat.equals(""))
			throw new ServiceException("Date formats cannot be null");
		
		pipelineCursor.destroy();
		
		try {
				SimpleDateFormat sdf = new SimpleDateFormat(startDateFormat);
				Date sdt = sdf.parse(startDateTime);
				SimpleDateFormat edf = new SimpleDateFormat(endDateFormat);
				Date edt = edf.parse(endDateTime);
				long  timediff = edt.getTime() - sdt.getTime();
		
		//		SimpleDateFormat ssdf = new SimpleDateFormat("HH:mm:ss");
		//		Calendar cal = Calendar.getInstance();
		//		cal.clear();
		//		cal.set(Calendar.SECOND, (int) timediff /1000);
		
		//		Date newDateTime = cal.getTime();
		//		String displayTime=null;
		
		//		if (cal.get(Calendar.DAY_OF_YEAR) > 1 )
		//		    displayTime = ssdf.format(newDateTime) + " and " + (cal.get(Calendar.DAY_OF_YEAR)-1) + " Day(s)" ;
		//		else 
		//		    displayTime = ssdf.format(newDateTime);
		
				String displayTimeSec = Long.toString(timediff/1000);
				String displayTimeMin = Long.toString(timediff/60000);
				String displayTimeHr = Long.toString(timediff/3600000);
				String displayTimeDay = Long.toString(timediff/86400000);
		
				// pipeline
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				pipelineCursor_1.last();
				pipelineCursor_1.insertAfter( "dateDifferenceSec", displayTimeSec);
				pipelineCursor_1.insertAfter( "dateDifferenceMin", displayTimeMin);
				pipelineCursor_1.insertAfter( "dateDifferenceHr", displayTimeHr);
				pipelineCursor_1.insertAfter( "dateDifferenceDay", displayTimeDay);
				pipelineCursor_1.destroy();
			} catch (ParseException e) {
				throw new ServiceException("Error parsing the date time: " + e);
			}
		// --- <<IS-END>> ---

                
	}



	public static final void calculateUptime (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(calculateUptime)>> ---
		// @sigtype java 3.5
		// [i] field:0:required startDateTime
		// [i] field:0:required endDateTime
		// [i] field:0:required startDateFormat
		// [i] field:0:required endDateFormat
		// [o] field:0:required uptime
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	startDateTime = "";
		String	endDateTime = "";
		String startDateFormat = "";
		String endDateFormat = "";
		if (pipelineCursor.first("startDateTime"))
		{
			startDateTime = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("endDateTime"))
		{
			endDateTime = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("startDateFormat"))
		{
			startDateFormat = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("endDateFormat"))
		{
			endDateFormat = (String) pipelineCursor.getValue();
		}
		
		if (startDateTime.equals("") || endDateTime.equals(""))
			throw new ServiceException("Dates cannot be null");
		if (startDateFormat.equals("") || endDateFormat.equals(""))
			throw new ServiceException("Date formats cannot be null");
		
		pipelineCursor.destroy();
		
		try {
				SimpleDateFormat sdf = new SimpleDateFormat(startDateFormat);
				Date sdt = sdf.parse(startDateTime);
				SimpleDateFormat edf = new SimpleDateFormat(endDateFormat);
				Date edt = edf.parse(endDateTime);
				long  timediff = edt.getTime() - sdt.getTime();
		
		//		SimpleDateFormat ssdf = new SimpleDateFormat("HH:mm:ss");
		//		Calendar cal = Calendar.getInstance();
		//		cal.clear();
		//		cal.set(Calendar.SECOND, (int) timediff /1000);
		
		//		Date newDateTime = cal.getTime();
		//		String displayTime=null;
		
		//		if (cal.get(Calendar.DAY_OF_YEAR) > 1 )
		//		    displayTime = ssdf.format(newDateTime) + " and " + (cal.get(Calendar.DAY_OF_YEAR)-1) + " Day(s)" ;
		//		else 
		//		    displayTime = ssdf.format(newDateTime);
		
				long days, hrs, mins, secs;
		
				days = timediff / 86400000;  
				timediff = timediff % 86400000;
				hrs = timediff / 3600000;  
				timediff = timediff % 3600000;
				mins = timediff / 60000;  
				timediff = timediff % 60000;
				secs = timediff / 1000;  
		
				String uptime="";
				
				if (days > 0) {
					uptime += Long.toString(days)+" days ";
				}
				uptime += Long.toString(hrs)+"h:";
				uptime += Long.toString(mins)+"m:";
				uptime += Long.toString(secs)+"s";
		
				// pipeline
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				pipelineCursor_1.last();
				pipelineCursor_1.insertAfter( "uptime", uptime);
				pipelineCursor_1.destroy();
			} catch (ParseException e) {
				throw new ServiceException("Error parsing the date time: " + e);
			}
		// --- <<IS-END>> ---

                
	}



	public static final void convertSecondsToDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertSecondsToDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dateFormat
		// [i] field:0:required seconds
		// [o] field:0:required date

	IDataCursor plc = pipeline.getCursor();

	String strSeconds = null;
	if (plc.first("seconds"))
	{
		strSeconds = (String)plc.getValue();
	}
	else
	{
		throw new ServiceException("seconds must be supplied!");
	} 
	String strDateFormat = null;
	if (plc.first("dateFormat"))
	{
		strDateFormat = (String)plc.getValue();
	}
	else
	{
		throw new ServiceException("dateFormat must be supplied!");
	}
	
	long seconds = Long.parseLong(strSeconds)*1000;
	Date fdate = new Date(seconds);

	SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
	String strDate = sdf.format(fdate);

	if (plc.first("date")) plc.delete();
	plc.insertAfter("date", "" + strDate );
	plc.destroy(); 
 
		// --- <<IS-END>> ---

                
	}



	public static final void getCurrentDateInSeconds (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCurrentDateInSeconds)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required seconds
			
		
		IDataCursor plc = pipeline.getCursor();
		
		Date now = new Date();
		
		if (plc.first("seconds")) plc.delete();
		plc.insertAfter("seconds", "" + now.getTime()/1000);
		plc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getDateFromFilename (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDateFromFilename)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required days
		// [o] field:0:required date
		IDataCursor pc = pipeline.getCursor();
		int days = 0;
		String filename = null;
		String posDate = "";
		
		
		if (pc.first("filename"))
		{
		    filename= (String) pc.getValue();
		    if (filename.length() > 12) {
			posDate = filename.substring(filename.length()-12,filename.length()-4); 
		
		try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				Date sdt = sdf.parse(posDate);
				days = (int)(((new Date()).getTime() - sdt.getTime())/86400000);
		
			} catch (ParseException e) {
			}
		    }
		} 
		
		if (pc.first("days")) pc.delete();
		pc.insertAfter("days","" + days);
		if (pc.first("date")) pc.delete();
		pc.insertAfter("date","" + posDate);
		
		// --- <<IS-END>> ---

                
	}
}

