package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-07-10 09:07:31 MEST
// -----( ON-HOST: itsbex05

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class documentlist

{
	// ---( internal utility methods )---

	final static documentlist _instance = new documentlist();

	static documentlist _newInstance() { return new documentlist(); }

	static documentlist _cast(Object o) { return (documentlist)o; }

	// ---( server methods )---




	public static final void appendToBuffer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(appendToBuffer)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:optional buffer
		// [i] record:1:optional list
		// [i] record:0:optional document
		// [i] field:0:optional prepend {"false","true"}
		// [o] object:0:optional buffer
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		Object buffer = IDataUtil.get(pc, "buffer");
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		IData document = IDataUtil.getIData(pc, "document");
		String prepend = IDataUtil.getString(pc, "prepend");
		
		LinkedList buff = null;
		if (buffer == null || !(buffer instanceof LinkedList)) {
			buff = new LinkedList();
		} else {
			buff = (LinkedList)buffer;
		}
		
		if (list != null) {
			buff.addAll(Arrays.asList(list));
		}
		
		if (document != null) {
			if (prepend != null && prepend.equals("true")) {
				buff.addFirst(document);
			} else {
				buff.addLast(document);
			}
		}
		
		IDataUtil.put(pc, "buffer", buff);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void bufferToList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(bufferToList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required buffer
		// [o] record:1:required list
		IDataCursor pc = pipeline.getCursor();
		Object buffer = IDataUtil.get(pc, "buffer");
		
		IData[] list = null;
		if (buffer != null && buffer instanceof LinkedList) {
			list = (IData[])((LinkedList)buffer).toArray(new IData[0]);
		}
		
		IDataUtil.put(pc, "list", list);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void chunk (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(chunk)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [i] field:0:required chunkSize
		// [o] record:1:required chunks
		// [o] - record:1:optional chunk
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		String chunksize = IDataUtil.getString(pc, "chunkSize");
		
		int size = 25;
		try {
			size = Integer.parseInt(chunksize);
		} catch (Exception e) {}
		
		IData[] chunks = __chunk(list, size);
		
		IDataUtil.put(pc, "chunks", chunks);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void concat (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(concat)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list1
		// [i] record:1:optional list2
		// [o] record:1:required list
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		IData[] list1 = IDataUtil.getIDataArray(pc, "list1");
		IData[] list2 = IDataUtil.getIDataArray(pc, "list2");
		
		IData[] list = __concat(list1, list2);
		
		IDataUtil.put(pc, "list", list);
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void contains (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(contains)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [i] record:0:optional document
		// [o] field:0:required contains
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		IData document = IDataUtil.getIData(pc, "document");
		
		IDataUtil.put(pc, "contains", String.valueOf(__contains(list, document)));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void containsKey (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(containsKey)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [i] field:0:optional key
		// [i] field:0:optional value
		// [o] field:0:required contains
		// [o] record:0:optional document
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		String key = IDataUtil.getString(pc, "key");
		String value = IDataUtil.getString(pc, "value");
		
		IData document = null;
		boolean contains = false;
		if (list != null && key != null) {
			for (int i = 0; i < list.length; i++) {
				if (__getValue(list[i], key).equals(value)) {
					contains = true;
					document = list[i];
					break;
				}
			}
		}
		IDataUtil.put(pc, "contains", String.valueOf(contains));
		IDataUtil.put(pc, "document", document);
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void crop (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(crop)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required documentList
		// [i] field:0:required removeItems
		// [i] field:0:required removeDirection {"from_start","from_end"}
		// [o] record:1:required documentList
		IDataCursor pc = pipeline.getCursor();
		IData[] array = IDataUtil.getIDataArray(pc, "stringList");
		int cropItems = new Integer(IDataUtil.getString(pc, "removeItems")).intValue();
		boolean cropFromStart = new Boolean(IDataUtil.getString(pc, "removeDirection")
			.equals("from_start")).booleanValue();
		
		IDataUtil.put(pc, "stringList", __truncate(array, cropItems, cropFromStart));
		pc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void elementAt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(elementAt)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [i] field:0:required index
		// [o] record:0:required document
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		String index = IDataUtil.getString(pc, "index");
		
		int idx = 0;
		try {
			idx = new Integer(index).intValue();
		} catch (Exception e) {}
		
		IData document = null;
		if (list != null && list.length > 0) {
			if (list.length > idx) {
				document = list[idx];
			} else {
				document = list[list.length - 1];
			}
		}
		IDataUtil.put(pc, "document", document);
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void filter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(filter)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional documentList
		// [i] field:0:required propertyName
		// [i] field:0:required propertyValue
		// [i] field:0:optional equals {"true","false"}
		// [i] field:0:optional pattern {"false","true"}
		// [i] field:0:optional bothLists {"false","true"}
		// [i] field:0:optional ignoreCase {"false","true"}
		// [o] record:1:optional filteredDocumentList
		// [o] record:1:optional filteredOutDocumentList
		IDataCursor pc = pipeline.getCursor();
		IData[] documentList = IDataUtil.getIDataArray(pc, "documentList");
		String sKey = IDataUtil.getString(pc, "propertyName");
		String sValue = IDataUtil.getString(pc, "propertyValue");
		String sEquals = IDataUtil.getString(pc, "equals");
		String sPattern = IDataUtil.getString(pc, "pattern");
		String sBothLists = IDataUtil.getString(pc, "bothLists");
		String sIgnoreCase = IDataUtil.getString(pc, "ignoreCase");
		
		boolean equals = sEquals != null && sEquals.equals("true");
		boolean like   = sPattern != null && sPattern.equals("true");
		boolean bothLists = sBothLists != null && sBothLists.equals("true");
		boolean ignoreCase = sIgnoreCase != null && sIgnoreCase.equals("true");
		ArrayList list = new ArrayList();
		ArrayList list2 = new ArrayList();
		
		// filter
		String restKey1 = sKey;
		if (sKey.indexOf("/") > 1) {
			restKey1 = sKey.substring(sKey.indexOf("/") + 1, sKey.length());
		}
		
		if (sValue != null && ignoreCase) {
			sValue = sValue.toLowerCase();
		}
		
		for (int i = 0; documentList != null && i < documentList.length; i++) {
			String value = __getValue(documentList[i], restKey1);
			if (value == null) {
				value = "";
			}
			if (ignoreCase) {
				value = value.toLowerCase();
			}
			if (equals) {
				if (sValue.equals(value)) {
					list.add(documentList[i]);
				} else if (like && value.indexOf(sValue) >= 0) {
					list.add(documentList[i]);
				} else if (bothLists) {
					list2.add(documentList[i]);
				}
			} else {
				if (!sValue.equals(value)) {
					list.add(documentList[i]);
				} else if (bothLists) {
					list2.add(documentList[i]);
				}
			}
		}
		
		if (list.size() > 0) {
			IDataUtil.put(pc, "filteredDocumentList", (IData[])list.toArray(new IData[0]));
		} else {
			IDataUtil.put(pc, "filteredDocumentList", null);
		}
		
		if (bothLists) {	
			if (list2.size() > 0) {
				IDataUtil.put(pc, "filteredOutDocumentList", (IData[])list2.toArray(new IData[0]));
			} else {
				IDataUtil.put(pc, "filteredOutDocumentList", null);
			}
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void forceList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(forceList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [o] record:1:required list
		IDataCursor pc = pipeline.getCursor();
		Object object = IDataUtil.get(pc, "list");
		
		IData[] list = null;
		if (object instanceof IData[]) {
			list = (IData[])object;
		} else {
			list = new IData[1];
			list[0] = (IData)object;
		}
		IDataUtil.put(pc, "list", list);
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void keys (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(keys)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [i] field:0:required key
		// [o] field:1:required keys
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		String key = IDataUtil.getString(pc, "key");
		
		String[] keys = __keys(list, key);
		
		IDataUtil.put(pc, "keys", keys);
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void size (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(size)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [o] field:0:required size
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		
		int size = 0;
		if (list != null) {
			size = list.length;
		}
		IDataUtil.put(pc, "size", String.valueOf(size));
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void sort (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sort)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [i] field:1:required keys
		// [i] field:0:required order {"ascending","descending"}
		// [o] record:1:required list
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		String[] keys = IDataUtil.getStringArray(pc, "keys");
		String order = IDataUtil.getString(pc, "order");
		
		IData[] sorted = __sort(list, keys, (order != null && order.equals("ascending")));
		
		IDataUtil.put(pc, "list", sorted);
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void split (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(split)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional list
		// [i] field:0:required key
		// [i] field:0:optional value
		// [o] record:1:required splits
		// [o] - field:0:required value
		// [o] - record:1:optional split
		// [o] field:0:optional exception
		IDataCursor pc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(pc, "list");
		String key = IDataUtil.getString(pc, "key");
		String value = IDataUtil.getString(pc, "value");
		
		IData[] split = null;
		if (value != null) {
			split = __split(list, key, value);
		} else {
			split = __split(list, key);
		}
		IDataUtil.put(pc, "splits", split);
		pc.destroy(); 
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	/**
	 * Returns a subset of the given document list.
	 * @param list
	 * @param start
	 * @param end
	 * @return Subset of document list.
	 */
	public static IData[] __subset(IData[] list, int start, int end) {
		
		IData[] subset = null; 
		if (list != null) {
			end = Math.min(list.length, end);
			subset = (IData[])new ArrayList(new ArrayList(Arrays.asList(list))
					.subList(start, end)).toArray(new IData[0]);
		}
		return subset;
	}
	
	/**
	 * Concatenates two document lists. 
	 * @param list1
	 * @param list2
	 * @param prepend
	 * @return Concatenated document list.
	 */
	public static IData[] __concat(IData[] list1, IData[] list2) {
		
		ArrayList list = new ArrayList();
		if (list1 != null) {
			list.addAll(Arrays.asList(list1));
		}
		if (list2 != null) {
			list.addAll(Arrays.asList(list2));
		}
		return (IData[])list.toArray(new IData[0]);
	}
	
	/**
	 * Sort a document list on a number of given keys.
	 * @param list
	 * @param keys
	 * @param ascending
	 * @return Sorted document list.
	 */
	public static IData[] __sort(IData[] unsorted, String[] keys, boolean ascending) {
	
		if (unsorted == null || unsorted.length == 0 
				|| keys == null || keys.length == 0) {
			return unsorted;
		}
		
		TreeSet sorted = new TreeSet(new DocumentComparator(ascending));
		for (int i = 0; i < unsorted.length; i++) {
			sorted.add(new ComparableDocument(unsorted[i], keys));
		}
		
		int i = 0;
		Iterator iterator = sorted.iterator();
	
		ArrayList sortedlist = new ArrayList();
		while (iterator.hasNext()) {
			sortedlist.add(((ComparableDocument)iterator.next()).getDocument());
		}
		return (IData[])sortedlist.toArray(new IData[0]);
	}
	
	/**
	 * Groups elements in a document list by given key in separate document lists.
	 * @param list
	 * @param key
	 * @return List of grouped lists.
	 */
	public static IData[] __split(IData[] list, String key) {
		
		HashMap sets = new HashMap();
		for (int i = 0; i < list.length; i++) {
			String value = __getValue(list[i], key);
			if (value == null || value.equals("")) {
				value = "null";
			}
			ArrayList values = (ArrayList)sets.get(value);
			if (values == null) {
				values = new ArrayList();
			}
			values.add(list[i]);
			sets.put(value, values);
		}
	
		IData[] splits = new IData[sets.size()];
		Iterator iterator = sets.keySet().iterator();
		int i = 0;
		while (iterator.hasNext()) {
			String value = (String)iterator.next();
			ArrayList split = (ArrayList)sets.get(value);
			splits[i] = IDataFactory.create();
			IDataCursor ic = splits[i].getCursor();
			IDataUtil.put(ic, "value", value);
			IDataUtil.put(ic, "split", (IData[])split.toArray(new IData[0]));
			ic.destroy();
			i++;
		}
		return splits;
	}
	
	/**
	 * Groups elements in a document list by whether or not they contain given key with 
	 * given value, in separate document lists.
	 * @param list
	 * @param key
	 * @return List of grouped lists.
	 */
	public static IData[] __split(IData[] list, String key, String value) {
		
		ArrayList equals = new ArrayList();
		ArrayList differs = new ArrayList();
		for (int i = 0; i < list.length; i++) {
			if (value.equals(__getValue(list[i], key))) {
				equals.add(list[i]);
			} else {
				differs.add(list[i]);
			}
		}
	
		IData[] splits = new IData[2];
		{
			splits[0] = IDataFactory.create();
			IDataCursor ic = splits[0].getCursor();
			IDataUtil.put(ic, "split", (IData[])equals.toArray(new IData[0]));
			ic.destroy();
		}
		{
			splits[1] = IDataFactory.create();
			IDataCursor ic = splits[1].getCursor();
			IDataUtil.put(ic, "split", (IData[])differs.toArray(new IData[0]));
			ic.destroy();
		}
	
		return splits;
	}
	
	/**
	 * Groups a document list in subsets of a maximum given length.
	 * @param list
	 * @param chunkSize
	 * @return List of subsets
	 */
	public static IData[] __chunk(IData[] list, int chunkSize) {
	
		ArrayList chunks = new ArrayList();
		if (list != null || list.length == 0 
				|| chunkSize == 0) { 
	
			int size = new Integer(chunkSize).intValue();
			int loadFactor = (int)Math.ceil((double)list.length / (double)size);
		
			int start = 0;
			for (int i = 0; i < loadFactor; i++) {
				IData chunk = IDataFactory.create();
				IDataCursor ic = chunk.getCursor();
				IDataUtil.put(ic, "chunk", (IData[])__subset(list, start, start + size));
				ic.destroy();
				start += size;
				chunks.add(chunk);
			}
		}
		
		return (IData[])chunks.toArray(new IData[0]);
	}
	
	/**
	 * Lists all values for a given key from a document list.
	 * @param list
	 * @param key
	 * @return String array of name/value pairs
	 */
	public static String[] __keys(IData[] list, String key) {
		
		String[] keys = new String[list.length];
		for (int i = 0; i < list.length; i++) {
			keys[i] = __getValue(list[i], key);
		}
		return keys;
	}
	
	/**
	 * Truncates a document list from either side.
	 * @param arraySrc
	 * @param cropItems
	 * @param cropFromStart
	 * @return Truncated document list.
	 */
	public static IData[] __truncate(IData[] list, int newSize, boolean fromStart) {
		
		IData[] cropped = new IData[list.length - newSize];
		int position = 0;
		int length = list.length;
		if (fromStart) {
		      position += newSize;
		}	
		System.arraycopy(list, position, cropped, 0, cropped.length);
		return cropped;
	}
	
	/**
	 * Returns boolean indicator whether element exists in list.
	 * @param list
	 * @param element
	 * @return Boolean existence indicator.
	 */
	public static boolean __contains(IData[] list, IData element) {
		
		return new ArrayList(Arrays.asList(list)).contains(element);
	}
	
	/**
	 * Returns the value of given field (XPath style) 
	 * @param itemData
	 * @param itemName
	 * @return Value of field.
	 */
	private static String __getValue(IData itemData, String itemName) {
		
		IDataCursor ic = itemData.getCursor();
		String result = "";
		
		if (itemName.indexOf("/") > 0) {
			String nextItemName = itemName.substring(0, itemName.indexOf("/"));
			IData nextItemData = IDataUtil.getIData(ic, nextItemName);
			if (nextItemData != null) {
				result = __getValue(nextItemData, itemName.substring(itemName.indexOf("/") + 1, itemName.length()));
			} else {
				result = "null";
			}
		} else {
			result = IDataUtil.getString(ic, itemName);
		}	
		ic.destroy();
		return result;
	}
	
	/**
	 * Inner container class for support in document comparison (sorting).
	 * @version 26-Apr-2006
	 */
	public static class ComparableDocument implements Comparable {
		private IData document = null;
		private String[] keys = null;
	
		/**
		 * Constructor
		 * @param document
		 * @param keys
		 */
		public ComparableDocument(IData document, String[] keys) {
			this.document = document;
			this.keys = keys;
		}
	
		/**
		 * Compare to another object
		 */
		public int compareTo(Object o) {
			return compareTo((ComparableDocument)o);
		}
	
		/**
		 * Compare to another comparable
		 */
		public int compareTo(ComparableDocument cd) {
			return compareTo(cd.getDocument());
		}
	
		/**
		 * Compare to another document
		 */
		public int compareTo(IData idata) {
			int result = 0;
			try {
				for (int i = 0; i < this.keys.length && result == 0; i++) {
					String keyA = __getValue(this.document, keys[i]);
					String keyB = __getValue(idata, keys[i]);
					result = keyA.compareToIgnoreCase(keyB);
				}
			}
			catch (Exception e) {}
			result = (result == 0) ? -1 : result;
			return result;
		}
	
		/**
		 * Return the document
		 */
		public IData getDocument() {
			return this.document;
		}
	
		/**
		 * Returns boolean equality indicator
		 */
		public boolean equals(Object o) {
			return compareTo(o) == 0;
		}
	}
	
	/**
	 * Inner utility class for support in document comparison (sorting).
	 * @version 26-Apr-2006
	 */
	public static class DocumentComparator implements Comparator {
		private boolean ascending = true;
	
		/**
		 * Constructor
		 */
		public DocumentComparator(boolean ascending) {
			this.ascending = ascending;
		}
	
		/**
		 * Compare two objects for sequence
		 */
		public int compare(Object a, Object b) {
			int result = 0;
			try {
				result = ((ComparableDocument)a).compareTo((ComparableDocument)b);
			}
			catch (Exception e) {}
			result = (result == 0) ? -1 : result;
			if (!this.ascending) {
				result *= -1;
			}
			return result;
		}
	
		/**
		 * Compares to objects for equality
		 */
		public boolean equals(Object a, Object b) {
			return compare(a, b) == 0;
		}
	}
	// --- <<IS-END-SHARED>> ---
}

