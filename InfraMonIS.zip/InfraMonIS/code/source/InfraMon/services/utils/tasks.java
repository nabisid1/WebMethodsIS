package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-07-10 16:48:28 CEST
// -----( ON-HOST: hpx147

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
import java.lang.*;
import com.wm.data.*;
import java.util.zip.CRC32;
// --- <<IS-END-IMPORTS>> ---

public final class tasks

{
	// ---( internal utility methods )---

	final static tasks _instance = new tasks();

	static tasks _newInstance() { return new tasks(); }

	static tasks _cast(Object o) { return (tasks)o; }

	// ---( server methods )---




	public static final void stringInStringList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringInStringList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required list
		// [i] field:0:required element
		// [o] field:0:required index
		// [o] field:0:required result
		IDataCursor pipelineCursor = pipeline.getCursor();
		String[] list    = IDataUtil.getStringArray( pipelineCursor, "list" );
		String   element = IDataUtil.getString( pipelineCursor, "element" );
		
		int index = -1;
		
		if (list != null && element != null)
		{
			for (int i = 0; i < list.length; i++)
			{
				if (list[i] != null && list[i].equals(element))
				{
					index = i;
					break;
				}
			}
		}
		
		IDataUtil.put( pipelineCursor, "index", String.valueOf(index));
		IDataUtil.put( pipelineCursor, "result", String.valueOf(index >= 0));
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static String getPropertyValueRecursive(IData document, String propertyName)
	{
		// deprecated!
		return getKeyValue(document, propertyName);
	}
	
	public static String getKeyValue(IData itemData, String itemName)
	{
		IDataCursor cursor = itemData.getCursor();
		String result = "";
	
		if (itemName.indexOf("/") > 0)
		{
			String nextItemName = itemName.substring(0, itemName.indexOf("/"));
			IData nextItemData = IDataUtil.getIData(cursor, nextItemName);
			if (nextItemData != null)
			{
				result = getKeyValue(nextItemData, itemName.substring(itemName.indexOf("/") + 1, itemName.length()));
			}
			else
			{
				result = "null";
			}
		}
		else
		{
			result = IDataUtil.getString(cursor, itemName);
		}	
		cursor.destroy();
		return result;
	}
	
	public static IData setKeyValue(IData itemData, String itemName, Object itemValue, String delimiter)
	{
		if (itemData == null)
		{
			itemData = IDataFactory.create();
		}
		IDataCursor cursor = itemData.getCursor();
	
		if (itemName.indexOf(delimiter) > 0)
		{
			String nextItemName = itemName.substring(0, itemName.indexOf(delimiter));
			IData nextItemData = IDataUtil.getIData(cursor, nextItemName);
			nextItemData = setKeyValue(nextItemData, itemName.substring(itemName.indexOf(delimiter) + delimiter.length(), itemName.length()), itemValue, delimiter);
			IDataUtil.put(cursor, nextItemName, nextItemData);
		}
		else
		{
			IDataUtil.put(cursor, itemName, itemValue);
		}	
		cursor.destroy();
		return itemData;
	}
	
	public static void log(String text)
	{
		try
		{
			FileOutputStream fout = new FileOutputStream("/webMdata/logpricelist.log", true);
			fout.write((text + "\n").getBytes());
			fout.close();
		} catch (Exception e) {}
	}
	
	public static class ComparableDocument implements Comparable
	{
		private IData document = null;
		private String[] keys = null;
		private boolean ascending = true;
	
		public ComparableDocument(IData document, String[] keys, boolean ascending)
		{
			this.document = document;
			this.keys = keys;
			this.ascending = ascending;
		}
	
		public int compareTo(IData idata)
		{
			int result = 0;
			try
			{
				for (int i = 0; i < this.keys.length && result == 0; i++)
				{
					String keyA = getPropertyValueRecursive(this.document, keys[i]);
					String keyB = getPropertyValueRecursive(idata, keys[i]);
					result = keyA.compareToIgnoreCase(keyB);
				}
			}
			catch (Exception e) {}
			result = (result == 0) ? -1 : result;
			if (!this.ascending)
			{
				result = result * -1;
			}
			return result;
		}
	
		public int compareTo(ComparableDocument cd)
		{
			return compareTo(cd.getDocument());
		}
	
		public int compareTo(Object o)
		{
			return compareTo((ComparableDocument)o);
		}
	
		public IData getDocument()
		{
			return this.document;
		}
	
		public boolean equals(Object o)
		{
			return compareTo(o) == 0;
		}
	}
	
	
	public static class DocumentComparator implements Comparator
	{
		private boolean ascending = true;
	
		public DocumentComparator(boolean ascending)
		{
			this.ascending = ascending;
		}
	
		public int compare(Object a, Object b)
		{
			ComparableDocument xa = (ComparableDocument)a;
			ComparableDocument xb = (ComparableDocument)b;
			int result = 0;
			try
			{
				result = xa.compareTo(xb);
			}
			catch (Exception e) {}
			return result;
		}
	
		public boolean equals(Object a, Object b)
		{
			return compare(a, b) == 0;
		}
	}
	
	public static long getCRCFromObject(Object object)
	{
		long crc = 0;
		try
		{
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			ObjectOutputStream out = new ObjectOutputStream(bout);
			out.writeObject(object);
			CRC32 crc32 = new CRC32();
			crc32.update(bout.toByteArray());
			crc = crc32.getValue();
			out.close();
			bout.close();
		}
		catch (Exception e) {}
		return crc;
	}
	
	public static ArrayList arrayToList(IData[] array)
	{
		ArrayList result = null;
		if (array != null )
		{
			result = new ArrayList(Arrays.asList(array));
		}
		return result;
	}
	
	public static IData[] listToArray(ArrayList list)
	{
		IData[] result = null;
		if (list != null )
		{
			result = (IData[])list.toArray(new IData[0]);
		}
		return result;
	}
	
	    /** Matches two string arrays of equal length.
		 * Nr of matches is recorded as well as at what index
		 * this occurred.
	     * @param values1 Input string list
		 * @param values2 Input string list 2
	     * @return An IData object with a 'match' indicator and an ArrayList with matching indexes
	     */
	private static IData match(String [] values1, String[] values2, String type) {
		
		int nrOfMatches = 0;   // Set up counter
		
		IData result = IDataFactory.create();  			// Create the IData for returning
		IDataCursor rc = result.getCursor();   			// plus a cursor on it
		ArrayList matchingFieldNrs = new ArrayList();   // Setup an empty ArrayList for the matching indexes
	
		// loop over the various values
		for (int i = 0 ; i < values1.length ; i ++) {
				
			// Note that if one or both of the strings is null, it's regarded as non-matching
	
			if (values1[i] != null && values2[i] != null && values1[i].equals(values2[i])) {
				nrOfMatches++;
				matchingFieldNrs.add(new MInteger(i));  // record the index at which the match occurred
			}
		}
		
		if ( (type.equals("AND") && nrOfMatches == values1.length) || (type.equals("OR") && nrOfMatches > 0) ||
			 (type.equals("XOR") && nrOfMatches == 1) 				) {
				rc.insertAfter("matches", new MBoolean(true));
				rc.insertAfter("matchingFieldNrs", matchingFieldNrs );
		}
		else {
			rc.insertAfter("matches", new MBoolean(false));
		}
		
		rc.destroy();
		return result;
	}
	
	
	public static class IDataBuffer {
	    
	    
	    /** Creates a new instance of IDataBuffer */
	    public IDataBuffer() {
	        iBuffer = new IData[INITIAL_SIZE];
	        capacity = iBuffer.length;
	        lastElementPtr = -1;
	    }
	    
	    /** Initializes the buffer with the passed IData object
	     * @param element IData object
	     */
	    public IDataBuffer(IData element) {
	        iBuffer = new IData[INITIAL_SIZE];
	        iBuffer[0] = element;
	        capacity = iBuffer.length;
	        lastElementPtr = -1;
	    }
	    
	    /** Initializes the buffer with a buffer array of the given size
	     * @param initialCapacity Size the buffer will initially be set to
	     */
	    public IDataBuffer(int initialCapacity) {
	        iBuffer = new IData[initialCapacity];
	        capacity = initialCapacity;
	        lastElementPtr = -1;
	    }
	    
	    /** Initializes the buffer with the passed IData object and
	     * sets the initial capacity of the buffer
	     * @param element The IData object the buffer will initialized with
	     * @param initialCapacity Initial size of the buffer
	     */    
	    public IDataBuffer(IData element, int initialCapacity) {
	        iBuffer = new IData[initialCapacity];
	        iBuffer[0] = element;
	        capacity = initialCapacity;
	        lastElementPtr = 0;
	        
	        
	    }
	    
	    /** Size the buffer will initially be set to */
	    public static final int INITIAL_SIZE = 16;
	    
	    /** The internal array of type IData that will act as the buffer */    
	    private IData [] iBuffer;
	    
	    int capacity;
	    
	    int lastElementPtr;
	    
	    /** Whenever this method is called, the size of the buffer
	     * is doubled
	     */    
	    private void growCapacity() {
	        if (capacity == 0)
	            capacity = 1;
	        int newCapacity = capacity * 2;
	        IData [] newIBuffer = new IData[newCapacity ];
	        //System.arraycopy(iBuffer, 0, newIBuffer, 0, iBuffer.length);
			for (int i=0 ; i < iBuffer.length; i++ ) {
				newIBuffer[i] = iBuffer[i];
			}
	        iBuffer = newIBuffer;
	        capacity = newCapacity;
	    }
	    
	    /** Calls <CODE>growCapacity()</CODE> as many times as necessary
	     * in order to make sure that <CODE>newCapacity</CODE> will fit
	     * into the buffer
	     * @param newCapacity The minimum the size the buffer should be able
	     * to contain
	     */    
	    private void ensureCapacity(int newCapacity) {
	        while (capacity < newCapacity)
	            growCapacity();
	        
	    }
	    
	    /** Appends an IData object to the existing array
	     * @param element The IData object to be added
	     * @return A reference to the buffer
	     */
	    public IDataBuffer append(IData element) {
	        
	        if ((++lastElementPtr)>= capacity )
	            growCapacity();
	        iBuffer[lastElementPtr] = element;
	        return this;
	    }
	    
	    /** Appends an IData object array to the buffer
	     * @param elements Array of IData objects to be added
	     * @return Returns a reference to the buffer
	     */
	    public IDataBuffer append(IData [] elements) {
	        
	        
	        ensureCapacity(lastElementPtr + elements.length + 1);
	        
	        for (int i = 0 ; i < elements.length ; i++) {
	
	            iBuffer[++lastElementPtr ] = elements[i];
	            
	        }
	        //lastElementPtr = lastElementPtr + elements.length;
	        return this;
	    }
	    
	    /** Returns a trimmed and indepenedent array the elements currently in the buffer
	     * @return IData array
	     */
	    public IData [] toArray() {
	        
	        IData[] retArray = new IData[lastElementPtr+1];
	        //System.arraycopy(iBuffer, 0, retArray, 0, retArray.length);
			for (int i=0 ; i < retArray.length; i++ ) {
				retArray[i] = iBuffer[i];
			}
	        return retArray;
	    }
	}
	
	/**
	* This method trims a string in an IData object 'in loco'
	* Depending on the parameter 'recursive', the same method
	* is called each time an IData object is encountered
	*/
		
	private static void trim(IData doc, boolean recursive) {
		
	IDataCursor udc = doc.getCursor();
		if (	udc.first() ) {
		
			do {
			   Object o = udc.getValue();
				   
	   		   if (o instanceof String) {
					udc.setValue(((String) o).trim() );
						
			   }
			   // If an IData object is encountered and recursive mode is on
	           // call this method again
		
	   		   if (o instanceof IData && recursive) {
					trim((IData) o);				
			   }	
	   		   if (o instanceof IData [] && recursive) {
				IData [] docArray = (IData [] ) o;
				for (int i = 0 ; i < docArray.length ; i++ ) {
					trim(docArray[i]);		
				}		
			   }	
	
						
			}	
			while (udc.next() );
		
			}
		udc.destroy();
	}
	
	/**
	* Convenience method. Calls 'trim' in non-recursive mode
	*/
		
	private static void trim(IData doc) {
		trim(doc, false);
	}
	
	
	public static void createSubList(Object[] list, int start, int end, int total, IDataCursor pc, String isStringList)
	{
		int next     = 0;
		int previous = -1;
	
		if (total > 0 && total < list.length)
		{
			end = start + total;
		} 
	
		start = Math.max(start, 0);
		end   = Math.max(start, Math.min(end, list.length));
	
		if (end < list.length)
		{
			next = end;
		}
		
		if (start > 0 && total < list.length)
		{	
			previous = Math.max(start - total, 0);
		}
		
		if (isStringList != null && isStringList.equals("true"))
		{
			IDataUtil.put( pc, "list", createCleanSubList((String[])list, start, end - start) );
		}
		else
		{
			IDataUtil.put( pc, "list", createCleanSubList((IData[])list, start, end - start) );
		}
		IDataUtil.put( pc, "next", String.valueOf(next));
		IDataUtil.put( pc, "previous", String.valueOf(previous));
		IDataUtil.put( pc, "from", String.valueOf(++start));
		IDataUtil.put( pc, "to", String.valueOf(end));
	}
	
	public static IData[] createCleanSubList(IData[] list, int start, int size)
	{
		ArrayList list2 = new ArrayList(Arrays.asList(list));
		int length = Math.min(size, list2.size() - start);
		return (IData[])list2.subList(start, start + length).toArray(new IData[0]);
	}
	
	public static String[] createCleanSubList(String[] list, int start, int size)
	{
		ArrayList list2 = new ArrayList(Arrays.asList(list));
		int length = Math.min(size, list2.size() - start);
		return (String[])list2.subList(start, start + length).toArray(new String[0]);
	}
	
	public static IData[] splitOnKeyJ(IData[] list, String key)
	{
		HashMap splits = new HashMap();
		for (int i = 0; i < list.length; i++)
		{
			String value = getValueJ(list[i], key);
			if (value == null || value.equals(""))
			{
				value = "null";
			}
			ArrayList values = (ArrayList)splits.get(value);
			if (values == null)
			{
				values = new ArrayList();
			}
			values.add(list[i]);
			splits.put(value, values);
		}
	
		int i = 0;
		list = new IData[splits.size()];
		Iterator iterator = splits.values().iterator();
		while (iterator.hasNext())
		{
			ArrayList split = (ArrayList)iterator.next();
			list[i] = IDataFactory.create();
			IDataCursor lc = list[i].getCursor();
			IDataUtil.put(lc, "split", (IData[])split.toArray(new IData[0]));
			lc.destroy();
			i++;
		}
		return list;
	}
	
	public static String getValueJ(IData itemData, String itemName)
	{
		IDataCursor ic = itemData.getCursor();
		String result = "";
		
		if (itemName.indexOf("/") > 0)
		{
			String nextItemName = itemName.substring(0, itemName.indexOf("/"));
			IData nextItemData = IDataUtil.getIData(ic, nextItemName);
			if (nextItemData != null)
			{
				result = getValueJ(nextItemData, itemName.substring(itemName.indexOf("/") + 1, itemName.length()));
			}
			else
			{
				result = "null";
			}
		}
		else
		{
			result = IDataUtil.getString(ic, itemName);
		}	
		ic.destroy();
		return result;
	}
	
	public static String[] sortJ(String[] list, boolean ascending)
	{
		if (list != null)
		{
			TreeSet sorted = new TreeSet(new StringComparator(ascending));
			for (int i = 0; i < list.length; i++)
			{
				sorted.add(new ComparableString(list[i]));
			}
	
			int i = 0;
			Iterator iterator = sorted.iterator();
			list = new String[sorted.size()];
			while (iterator.hasNext())
			{
				list[i++] = ((ComparableString)iterator.next()).getString();
			}
		}
		return list;
	}
	
	public static class ComparableString implements Comparable
	{
		private String string = null;
	
		public ComparableString(String string)
		{
			this.string = string;
		}
	
		public int compareTo(Object o)
		{
			return compareTo((ComparableString)o);
		}
	
		public int compareTo(ComparableString cs)
		{
			return compareTo(cs.getString());
		}
	
		public int compareTo(String string)
		{
			int result = 0;
			try
			{
				result = this.string.compareToIgnoreCase(string);
			}
			catch (Exception e) {}
			result = (result == 0) ? -1 : result;
			return result;
		}
	
		public String getString()
		{
			return this.string;
		}
	
		public boolean equals(Object o)
		{
			return compareTo(o) == 0;
		}
	}
	
	public static class StringComparator implements Comparator
	{
		private boolean ascending = true;
	
		public StringComparator(boolean ascending)
		{
			this.ascending = ascending;
		}
	
		public int compare(Object a, Object b)
		{
			int result = 0;
			try
			{
				result = ((ComparableString)a).compareTo((ComparableString)b);
			}
			catch (Exception e) {}
			result = (result == 0) ? -1 : result;
			if (!this.ascending)
			{
				result *= -1;
			}
			return result;
		}
	
		public boolean equals(Object a, Object b)
		{
			return compare(a, b) == 0;
		}
	}
	// --- <<IS-END-SHARED>> ---
}

