package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-04-07 15:25:51 CEST
// -----( ON-HOST: rboshuis-1.InfraMon.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.*;
import java.sql.*;
import java.util.*;
import java.text.*;
// --- <<IS-END-IMPORTS>> ---

public final class jdbc

{
	// ---( internal utility methods )---

	final static jdbc _instance = new jdbc();

	static jdbc _newInstance() { return new jdbc(); }

	static jdbc _cast(Object o) { return (jdbc)o; }

	// ---( server methods )---




	public static final void emptyWmTable (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(emptyWmTable)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required olderThanDate
		// [i] field:0:required format
		// [i] field:0:required table {"wmerror","wmsession","wmservice"}
		// [o] field:0:required result
		// [o] field:0:required exception
		IDataCursor pc = pipeline.getCursor();
		String date = IDataUtil.getString(pc, "olderThanDate");
		String format = IDataUtil.getString(pc, "format");
		String table = IDataUtil.getString(pc, "table");
		
		String sql = "delete from wbm." + table;
		long result = 0;
		try {
			if (date != null) {
				long before = (new SimpleDateFormat(format).parse(date)).getTime();
				sql += " where audittimestamp < " + before;
			}
			result = updateDB(sql, "ISCoreAudit");
			
		} catch (Exception e) {
			IDataUtil.put(pc, "exception", e.toString());
		}
		IDataUtil.put(pc, "result", "" + result);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void execInternalSQL (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(execInternalSQL)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required sql
		// [i] field:0:required action {"select","insert","update","delete"}
		// [i] field:0:required alias
		// [o] record:1:required results
		// [o] field:0:required rowcount
		// [o] field:0:required exception
		IDataCursor pc = pipeline.getCursor();
		String sql = IDataUtil.getString(pc, "sql");
		String action = IDataUtil.getString(pc, "action");
		String alias = IDataUtil.getString(pc, "alias");
		
		try {
			if (action.equals("select") && sql.indexOf("select") >= 0) {
		    	IData[] results = queryDB(sql, alias);
		        IDataUtil.put(pc, "results", results);
		        IDataUtil.put(pc, "rowcount", "" + results.length);
			} else if ((action.equals("insert") || action.equals("update") || action.equals("delete")) && sql.indexOf("select") == -1) {
		    	IDataUtil.put(pc, "rowcount", "" + updateDB(sql, alias));
			}
		}
		catch (Exception e) {
			IDataUtil.put(pc, "exception", e.toString());
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static void resetAllPoolsJ() throws Exception {
		JDBCConnectionManager.reinitAllPools();
	}
	
	public static Connection getConnection(String alias) throws Exception {
		return JDBCConnectionManager.getConnection(alias);
	}
	
	public static void releaseConnection(String alias, Connection conn) throws Exception {
		JDBCConnectionManager.releaseConnection(alias, conn);
	}
	
	public static IData[] queryDB(String sql, String alias) throws Exception {
		ResultSet result = null;
	    Connection conn = null;
	    ArrayList results = new ArrayList();
	    try {
			conn = getConnection(alias);
	        Statement stmt = conn.createStatement();
	        result = stmt.executeQuery(sql);
	
	        while (result.next()) {
				IData idata = IDataFactory.create();
	            IDataCursor ic = idata.getCursor();
	            ResultSetMetaData rsmd = result.getMetaData();
	            int cols = rsmd.getColumnCount();
	            for (int i = 1; i <= cols; i++) {
					String label = rsmd.getColumnLabel(i);
	                String type = rsmd.getColumnTypeName(i);
	                String value = "[can't display type]";
	
	                if (type.indexOf("char") >= 0) {
						value = (String)result.getString(i);
	                } else if (type.indexOf("number") >= 0) {
						value = "" + result.getBigDecimal(i);
					}
					IDataUtil.put(ic, label, value);
				}
	            ic.destroy();
	            results.add(idata);
			}
	        stmt.close();
		} catch (Exception e) {
			throw new ServiceException("Could not get data with '" + sql + "'.\n" + e.toString());
		} finally {
			if (conn != null) {
				releaseConnection(alias, conn);
			}
		}
	    return (IData[])results.toArray(new IData[0]);
	}
	
	public static int updateDB(String sql, String alias) throws Exception {
		int result = 0;
	    Connection conn = null;
	    try {
			conn = getConnection(alias);
	        Statement stmt = conn.createStatement();
	        result = stmt.executeUpdate(sql);
	        stmt.close();
		} catch (Exception e) {
			throw new ServiceException("Could not put data with '" + sql + "'.\n" + e.toString());
		} finally {
			if (conn != null) {
				releaseConnection(alias, conn);
			}
		}
	    return result;
	}
	
	// --- <<IS-END-SHARED>> ---
}

