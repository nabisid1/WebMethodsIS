package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-09-28 11:46:02 CEST
// -----( ON-HOST: hpx96

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class error

{
	// ---( internal utility methods )---

	final static error _instance = new error();

	static error _newInstance() { return new error(); }

	static error _cast(Object o) { return (error)o; }

	// ---( server methods )---




	public static final void throwException (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(throwException)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required errorMessage
		
		IDataCursor pc = pipeline.getCursor();
		String message = IDataUtil.getString(pc, "errorMessage");
		pc.destroy();
		
		throw new ServiceException(message);
		// --- <<IS-END>> ---

                
	}
}

