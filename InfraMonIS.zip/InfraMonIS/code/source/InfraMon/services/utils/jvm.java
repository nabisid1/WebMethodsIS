package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-03-13 12:56:52 GMT
// -----( ON-HOST: 172.16.232.131

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class jvm

{
	// ---( internal utility methods )---

	final static jvm _instance = new jvm();

	static jvm _newInstance() { return new jvm(); }

	static jvm _cast(Object o) { return (jvm)o; }

	// ---( server methods )---




	public static final void systemGC (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(systemGC)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		System.gc();
		// --- <<IS-END>> ---

                
	}
}

