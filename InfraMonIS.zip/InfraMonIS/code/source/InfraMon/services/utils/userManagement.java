package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2008-11-28 14:56:01 CET
// -----( ON-HOST: hpx213.ncsbe.eu.jnj.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.IOException;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class userManagement

{
	// ---( internal utility methods )---

	final static userManagement _instance = new userManagement();

	static userManagement _newInstance() { return new userManagement(); }

	static userManagement _cast(Object o) { return (userManagement)o; }

	// ---( server methods )---




	public static final void groupAddUser (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(groupAddUser)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required user
		// [i] field:0:required group
        IDataCursor pc = pipeline.getCursor();
        String groupName = "";
        String username = "";
        if(pc.first("group"))
            groupName = (String)pc.getValue();
        if(pc.first("user"))
            username = (String)pc.getValue();
        pc.destroy();
        com.wm.app.b2b.server.User user = UserManager.getUser(username);
        if(user == null)
        {
            IData errorpipe = IDataFactory.create();
            IDataCursor ec = errorpipe.getCursor();
            ec.insertAfter("key", "USER_NOTEXIST");
            ec.insertAfter("values", new String[] {
                username
            });
            ec.destroy();
            //throwBundleException(errorpipe);
        }
        Group gp = UserManager.getGroup(groupName);
        if(gp == null)
        {
            IData errorpipe = IDataFactory.create();
            IDataCursor ec = errorpipe.getCursor();
            ec.insertAfter("key", "GROUP_NOTEXIST");
            ec.insertAfter("values", new String[] {
                groupName
            });
            ec.destroy();
            //throwBundleException(errorpipe);
        }
        gp.add(user);
        UserManager.save();
        try
        {
            ACLManager.save();
        }
        catch(IOException ioe)
        {
            throw new ServiceException(ioe);
        }
		// --- <<IS-END>> ---

                
	}



	public static final void groupRemoveUser (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(groupRemoveUser)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required user
		// [i] field:0:required group
        IDataCursor pc = pipeline.getCursor();
        String groupName = "";
        String username = "";
        if(pc.first("group"))
            groupName = (String)pc.getValue();
        if(pc.first("user"))
            username = (String)pc.getValue();
        pc.destroy();
        com.wm.app.b2b.server.User user = UserManager.getUser(username);
        if(user == null)
        {
            IData errorpipe = IDataFactory.create();
            IDataCursor ec = errorpipe.getCursor();
            ec.insertAfter("key", "USER_NOTEXIST");
            ec.insertAfter("values", new String[] {
                username
            });
            ec.destroy();
            //throwBundleException(errorpipe);
        }
        Group gp = UserManager.getGroup(groupName);
        if(gp == null)
        {
            IData errorpipe = IDataFactory.create();
            IDataCursor ec = errorpipe.getCursor();
            ec.insertAfter("key", "GROUP_NOTEXIST");
            ec.insertAfter("values", new String[] {
                groupName
            });
            ec.destroy();
            //throwBundleException(errorpipe);
        }
        gp.remove(user);
        UserManager.save();
        try
        {
            ACLManager.save();
        }
        catch(IOException ioexception)
        {
            throw new ServiceException();
        }
		// --- <<IS-END>> ---

                
	}
}

