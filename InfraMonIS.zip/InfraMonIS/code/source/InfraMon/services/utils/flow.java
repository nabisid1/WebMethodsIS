package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-05-31 17:19:13 CEST
// -----( ON-HOST: rboshuis-1.InfraMon.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.InetAddress;
import java.net.UnknownHostException;
import com.wm.util.Debug;
import java.io.*;
import java.util.*;
import java.lang.System;
import com.wm.app.b2b.server.*;
import com.wm.util.Table;
import java.text.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class flow

{
	// ---( internal utility methods )---

	final static flow _instance = new flow();

	static flow _newInstance() { return new flow(); }

	static flow _cast(Object o) { return (flow)o; }

	// ---( server methods )---




	public static final void getServiceName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceName)>> ---
		// @sigtype java 3.5
		// [o] field:0:required folderName
		// [o] field:0:required serviceName
		// [o] field:0:required fullName
		// [o] field:0:required successFlag
		// [o] field:0:required errorMessage
		/** Service is designed to return the current service name.
		  * Output: folderPath - the folder path to the service
		  *			serviceName - the service name
		  *			fullName - the folder path + ":" + service
		  *			successFlag - true or false
		  *			errorMessage - error detail. This is set to "None" if no error occurs.
		  * 
		  * NOTE 1: Because this service relies on a method invocation that retrieves the NSService
		  * 	object relating to the calling service, it will *NOT* work as desired if run independently.
		  * 	Instead, it will return information on the current service (this one) and set the
		  *		"successFlag" and "errorMessage" values to indicate an error.
		  * NOTE 2: This service uses non-public APIs within the webMethods Integration Server. These may 
		  * 	change in future releases of the product *without* notice. These method invocations are
		  *		marked as such.
		  *
		  * @author Ryan Johnston, Professional Services, webMethods, Inc.
		  * @version 1.0
		  */
		
		//Instantiate a cursor for access to the pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		//Working & Output Variables - Create all output & working variables
		NSService callingService = null;
		StringTokenizer strTok = null;
		String folderPath = new String();
		String serviceName = new String();
		String fullName = new String();
		String successFlag = "true";
		String errorMessage = "None";
		
		//Input Variables
		//None
		
		//Service Body
		//This publicly documented method gets the NSService object associated with the calling service.
		callingService = Service.getCallingService();
		
		/** If the callingService is not available (meaning that the service was run directly, set the 
		  * "callingService" to hold the values for the current service (this one). Additionally, set the
		  * "successFlag" and "errorMessage" fields to indicate a problem.
		  */
		if (callingService == null)
		{
			callingService = InvokeState.getCurrentService();
			successFlag = "false";
			errorMessage = "No calling service found... Returning information for this service instead.";
		}
		
		/** Non-public API. However, this call is relatively safe, as "toString" is a standard method that
		  * is normally overriden from the root java.lang.Object.
		  */
		fullName = callingService.toString();
		
		/** Use StringTokenizer, from the java.util package, to extract the folderPath and serviceName 
		  * values.
		  */
		try
		{
			strTok = new StringTokenizer(fullName, ":");
			folderPath = strTok.nextToken();
			serviceName = strTok.nextToken();
		}
		catch(java.lang.Exception ex)
		{
			System.out.println("CRITICAL ERROR: Check the toString() method within NSService to ensure that it is returning Folder:ServiceName as desired.");
			successFlag = "false";
			errorMessage = "CRITICAL ERROR: Check the toString() method within NSService to ensure that it is returning Folder:ServiceName as desired.";
		
		}
		
		//Populate service output
		if (pipelineCursor.first("folderPath"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("folderPath", folderPath);
		
		if (pipelineCursor.first("serviceName"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("serviceName", serviceName);
		
		if (pipelineCursor.first("fullName"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("fullName", fullName);
		
		if (pipelineCursor.first("successFlag"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("successFlag", successFlag);
		
		if (pipelineCursor.first("errorMessage"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("errorMessage", errorMessage);
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	/** Used by "deepConvert"
	  * 
	  * @author Ryan Johnston, Professional Services, webMethods, Inc.
	  * @version 1.0
	  */
	private static final Values convert(Hashtable hT){
		//Following statement gets all arrays in this object.
		boolean nullFlag = false;
		Object[] hTArray = hT.values().toArray();
		Enumeration hTEnumeration = hT.keys();
		Values outbound = new Values();
	
		for(int i=0;i<hTArray.length;i++){
			String key = (String)hTEnumeration.nextElement();
			if(hTArray[i] instanceof java.lang.String){
				outbound.put(key,(String)hTArray[i]);
			}
			else if(hTArray[i] instanceof java.util.Hashtable){
				Values internalObject = convert((Hashtable)hTArray[i]);
				if(internalObject == null){
					nullFlag = true;
					return null;
				}
				outbound.put(key,internalObject);						
			}
			else{
				System.out.println("Conversion Failure:" + "unsupported type within inbound Hashtable.");
				return null;
			}
		}
		return outbound; 
	}
	
	public static final int MAXSLEEP = 3600000;  // one hr
	// --- <<IS-END-SHARED>> ---
}

