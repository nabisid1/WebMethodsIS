package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2004-10-27 16:41:06 CEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class memory

{
	// ---( internal utility methods )---

	final static memory _instance = new memory();

	static memory _newInstance() { return new memory(); }

	static memory _cast(Object o) { return (memory)o; }

	// ---( server methods )---




	public static final void deepCopy (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deepCopy)>> ---
		// @sigtype java 3.5
		// [i] object:0:required originalObject
		// [o] object:0:required clonedObject
		
			IDataCursor idcPipeline = pipeline.getCursor();
			if (!idcPipeline.first("originalObject"))
			{
				throw new ServiceException("originalObject is null!");
			}
			Object originalObject = (Object)idcPipeline.getValue();
			Object clonedObject = new Object();
		
		//	throw new ServiceException("blah" + (originalObject.getClass()).isArray());
		
			// This code is taken from http://www.javaworld.com/javaworld/javatips/jw-javatip76.html
			ObjectOutputStream oos = null;
			ObjectInputStream ois = null;
		
			try
			{
				ByteArrayOutputStream bos = new ByteArrayOutputStream(); // A
				oos = new ObjectOutputStream(bos); // B
		
				// serialize and pass the object
				oos.writeObject(originalObject); // C
				oos.flush(); // D
		
				ByteArrayInputStream bin = new ByteArrayInputStream(bos.toByteArray()); // E
				ois = new ObjectInputStream(bin); // F
		
				// return the new object
				idcPipeline.insertAfter("clonedObject", ois.readObject()); // G
			}
			catch (Exception e)
			{
				throw new ServiceException("Exception making deep copy of object: " + e);
			}
			finally
			{
				try
				{
					oos.close();
					ois.close();
				}
				catch (Exception e)
				{
					throw new ServiceException("Exception making deep copy of object: " + e);
				}
				idcPipeline.destroy();
			}
		// --- <<IS-END>> ---

                
	}



	public static final void getDataFromMemory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDataFromMemory)>> ---
		// @sigtype java 3.5
		// [i] field:0:required MemoryKey
	// Get cursor to pipeline IData object
	IDataCursor idcPipeline = pipeline.getCursor();
 
	// Initialize variables
	String strMemoryKey = null;
	IData idMemory = null;

	// Get data out of pipeline
	if (idcPipeline.first("MemoryKey"))
	{
		strMemoryKey = (String) idcPipeline.getValue();
	}
	else
	{	
		return;
	}

	idMemory = (IData) Memory.get(strMemoryKey);
	if (idMemory == null)
	{
		return;
	}


	// Put session object into pipeline
	idcPipeline.insertAfter("MemoryData", idMemory);
	
	// Always destroy your cursors
	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void listKeysInMemory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listKeysInMemory)>> ---
		// @sigtype java 3.5
		// [o] field:1:required MemoryKeys
	// Get cursor on pipeline object for data manipulation
	IDataCursor idcPipeline = pipeline.getCursor();

	// Gets a list of all of the keys and places them in a String[]
	Enumeration keys = Memory.keys();
	if (keys != null)
	{
		Vector idVector = new Vector();
		while (keys.hasMoreElements())
		{
			String id = (String) keys.nextElement();
			idVector.addElement(id);
		}
	    
     	int idCount = idVector.size();
	 	if (idCount >0)
	 	{	
			String[] MemoryKeys = new String[idCount];
			idVector.copyInto(MemoryKeys);
			
			// Put data into pipeline
			idcPipeline.insertAfter("MemoryKeys", MemoryKeys);
	 	}
	
	}

	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void removeDataFromMemory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeDataFromMemory)>> ---
		// @sigtype java 3.5
		// [i] field:0:required MemoryKey
	// Get cursor to pipeline IData object
	IDataCursor idcPipeline = pipeline.getCursor();

	// Initialize variables
	String strMemoryKey = null;

	// Get data out of pipeline
	if (idcPipeline.first("MemoryKey"))
	{
		strMemoryKey = (String) idcPipeline.getValue();
	}
	else
	{	
		return;
	}
	


	IData idMemory = (IData) Memory.get(strMemoryKey);
	if (idMemory == null)
	{
		return;
	}

	
	// Remove the specified record from memory
	Memory.remove(strMemoryKey);

	// place record object back in pipeline
	idcPipeline.insertAfter("MemoryData", idMemory);
	
	// Always destroy cursor
	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void saveDataToMemory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(saveDataToMemory)>> ---
		// @sigtype java 3.5
		// [i] field:0:required MemoryKey
			// Get cursor to pipeline IData object
			IDataCursor idcPipeline = pipeline.getCursor();
		
			// Initialize variables
			String strMemoryKey = null;
			IData idMemory = null;
		
			// Get data out of pipeline
			if (idcPipeline.first("MemoryKey"))
			{
				strMemoryKey = (String) idcPipeline.getValue();
			}
			else
			{	
				return;
			}
			
			if (idcPipeline.first("MemoryData"))
			{
				
		idMemory = (IData) idcPipeline.getValue();
			}
			else
			{	
				return;
			}
		
			
			// Place the MemoryData object into the Memory values object
			Memory.put(strMemoryKey, idMemory);
		
			// Always destroy cursor
			idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	protected static Values Memory = new Values();
	 
	// --- <<IS-END-SHARED>> ---
}

