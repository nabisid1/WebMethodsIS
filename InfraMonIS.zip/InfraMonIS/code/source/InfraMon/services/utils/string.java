package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-06-23 14:06:08 MEST
// -----( ON-HOST: itsbex05

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.util.regex.*;
import java.lang.*;
// --- <<IS-END-IMPORTS>> ---

public final class string

{
	// ---( internal utility methods )---

	final static string _instance = new string();

	static string _newInstance() { return new string(); }

	static string _cast(Object o) { return (string)o; }

	// ---( server methods )---




	public static final void replace (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(replace)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required string
		// [i] field:0:required find
		// [i] field:0:required replace
		// [i] field:0:optional repeat {"true","false"}
		// [i] field:0:optional ignoreCase {"true","false"}
		// [o] field:0:required string
		IDataCursor pc = pipeline.getCursor();
		String string = IDataUtil.getString(pc, "string");
		String find = IDataUtil.getString(pc, "find");
		String replace = IDataUtil.getString(pc, "replace");
		String repeat = IDataUtil.getString(pc, "repeat");
		String ignore = IDataUtil.getString(pc, "ignoreCase");
		
		Pattern p = null;
		try {
		if (ignore != null && ignore.equals("true")) {
		
			p = Pattern.compile(find, Pattern.CASE_INSENSITIVE);
		} else {
			p = Pattern.compile(find);
		}
		} catch (Exception e) {
			throw new ServiceException (e);
			}
		Matcher m = p.matcher(string);
		
		try {
		if (repeat != null && repeat.equals("true")) {
			string = m.replaceAll(replace);
		} else {
			string = m.replaceFirst(replace);
		}
		} catch (Exception ex) {
			throw new ServiceException (ex);
			}
		IDataUtil.put(pc, "string", string);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static final int __DECA  = 10;
	private static final int __OCTA  = 8;
	private static final int __HEXA  = 16;
	private static final int __CRAZY = 32;
	
	public static String __hexOnVarBase(long decimal, int base) {
	
		long rem;
	    String output="";
	    String digit;
	    String backwards="";
	    	
	    do {
	   		rem = decimal % base;
	   		digit = __convert(rem);
	   		decimal = decimal / base;
				output += digit;
	   	} while((decimal / base) != 0);
	
	   	rem = decimal % base;
	   	digit = __convert(rem);
	   	output = output + digit;
	    	for(int i = output.length() - 1; i >= 0; i--) {
	   		backwards += output.charAt(i);
	   	}
	   	return backwards;
	}
	
	private static String __convert(long rem) {		
	
		if (rem >= 10 && rem < 33) {
			char[] s = { (char)(rem + 55) };
			return String.valueOf(s);
		} else {
			return String.valueOf(rem);
		}
	}
	
	public static String[] __tokenize(String string, String token) {
	
		StringTokenizer st = new StringTokenizer(string, token);
		String[] stringList = new String[st.countTokens()];
		int i = 0;
	
		while (st.hasMoreTokens()) {
			stringList[i++] = st.nextToken();
		}
		return stringList;
	}
	
	public static String __truncate(String string, int length, boolean direction) {
	
		String trunc = "";
		if (direction) {	
			if (length < 0) {
				trunc = "";
			} else {
				trunc = string.substring(0, length);
			}
		} else {	
			if (length > string.length()) {
				trunc = "";
			} else {
				trunc = string.substring(string.length() - length, string.length());
			}
		}
		return trunc;
	}
	
	public static String __replace(String string, String find, String replace, boolean repeat) {
	
		if (string != null) {
			while (string.indexOf(find) >= 0) {
				string = string.substring(0, string.indexOf(find)) + replace 
					+ string.substring(string.indexOf(find) + find.length(), string.length());
				if (!repeat) {
					break;
				}
			}
		}
		return string;
	}
	
	public static String[] __fromEnumeration(Enumeration e) {
		ArrayList list = new ArrayList();
		while (e.hasMoreElements()) {
			list.add((String)e.nextElement());
		}
		return (String[])list.toArray(new String[0]);
	}
	
	private static String[] _sortStrings(String[] list, boolean ascend, boolean unique) {
	
		if (list != null) {
			TreeSet sorted = new TreeSet();
	
			for (int i = 0; i < list.length; i++) {
				if (unique) {
					if (sorted.contains(list[i])) {
						continue;
					}
				}
				sorted.add(list[i]);
			}
	
			// If required, reverse order
			ArrayList values = new ArrayList(sorted);
			if (!ascend) {
				Collections.reverse(values);
			}
			list = (String[])values.toArray(new String[0]);
		}
		return list;
	}
	// --- <<IS-END-SHARED>> ---
}

