package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2008-11-28 14:35:25 CET
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class convert

{
	// ---( internal utility methods )---

	final static convert _instance = new convert();

	static convert _newInstance() { return new convert(); }

	static convert _cast(Object o) { return (convert)o; }

	// ---( server methods )---




	public static final void stringListToString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringListToString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required stringList
		// [i] field:0:optional separator
		// [o] field:0:required string
		IDataCursor pc = pipeline.getCursor();
		
		String[] list = IDataUtil.getStringArray(pc, "stringList");
		String sep = IDataUtil.getString(pc, "separator");
		
		if (sep == null) {
			sep = ",  ";
		}
		
		StringBuffer buffer = new StringBuffer();
		String separator = "";
		if (list != null) {
			for (int i = 0; i < list.length; i++) {
				buffer.append(separator).append(list[i]);
				if (i == 0) { 
					separator = sep;
				}
			}
		}
		
		IDataUtil.put(pc, "string", buffer.toString());
		pc.destroy();
		// --- <<IS-END>> ---

                
	}
}

