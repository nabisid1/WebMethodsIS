package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2004-09-21 15:32:46 CEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class is

{
	// ---( internal utility methods )---

	final static is _instance = new is();

	static is _newInstance() { return new is(); }

	static is _cast(Object o) { return (is)o; }

	// ---( server methods )---




	public static final void removePipelineVariable (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removePipelineVariable)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required pipelinevar
	IDataCursor idcPipelineVar = pipeline.getCursor();
	IDataCursor idcDelete = pipeline.getCursor();

	String pipelinevar = null;
	if (idcPipelineVar.first("pipelinevar"))
	{
		if (idcDelete.first((String)idcPipelineVar.getValue()))
		{
			idcDelete.delete();
		}
		idcPipelineVar.delete();
	}
	idcPipelineVar.destroy();
	idcDelete.destroy();
		// --- <<IS-END>> ---

                
	}
}

