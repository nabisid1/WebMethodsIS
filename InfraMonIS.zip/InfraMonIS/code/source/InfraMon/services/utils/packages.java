package InfraMon.services.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-06-23 13:38:50 MEST
// -----( ON-HOST: itsbex05

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import com.wm.util.coder.*;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class packages

{
	// ---( internal utility methods )---

	final static packages _instance = new packages();

	static packages _newInstance() { return new packages(); }

	static packages _cast(Object o) { return (packages)o; }

	// ---( server methods )---




	public static final void getCurrentPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCurrentPackage)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required packageName
		
		IDataCursor pc = pipeline.getCursor();
		try {
		IDataUtil.put(pc, "packageName", Service.getServiceEntry().getPackage().getName());
		} catch (Exception e) {}
		
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] field:0:required _version
		// [o] field:0:required _build
		// [o] field:0:required _patches
		// [o] field:0:required _jvm
		IDataCursor pc = pipeline.getCursor();
		String name = IDataUtil.getString(pc, "packageName");
		
		com.wm.app.b2b.server.Package pkg = null;
		try
		{
			pkg = PackageManager.getPackage(name);
			if (pkg == null)
			{
				throw new ServiceException("Package does not exist");
			}
			File dir = pkg.getStore().getPackageDir();
			File manifest = new File(dir, "manifest.v3");
			XMLCoder coder = new XMLCoder();
			Values manValues = coder.readFromFile(manifest);
			
			IDataUtil.put(pc, "_version", manValues.getString("version"));
			IDataUtil.put(pc, "_build", manValues.getString("build"));
			IDataUtil.put(pc, "_patches", manValues.getString("patch_nums"));
			IDataUtil.put(pc, "_jvm", manValues.getString("jvm_version"));
		}
		catch (Exception e)
		{
			throw new ServiceException(e.toString());
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}
}

