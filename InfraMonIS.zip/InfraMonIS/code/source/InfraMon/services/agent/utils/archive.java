package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:22:24 MEST

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.zip.*;
import java.io.*;
import java.util.Enumeration;
import java.util.Vector;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class archive

{
	// ---( internal utility methods )---

	final static archive _instance = new archive();

	static archive _newInstance() { return new archive(); }

	static archive _cast(Object o) { return (archive)o; }

	// ---( server methods )---




	public static final void zipFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(zipFiles)>> ---
		// @sigtype java 3.5
		// [i] field:0:required sourcePath
		// [i] field:0:required zipFileName
		// [o] field:0:required numFilesZipped
		IDataCursor pc = pipeline.getCursor();
		String strSourcePath = IDataUtil.getString(pc, "sourcePath");
		String strZipFileName = IDataUtil.getString(pc, "zipFileName");
		
		if (strSourcePath == null) {
			throw new ServiceException("Nothing to zip!");
		}
		
		if (strZipFileName == null) {
			strZipFileName = "default.zip";
		}
		
		FileOutputStream fileos = null;
		BufferedOutputStream buffileos = null;
		ZipOutputStream zipos = null;
		
		int intNumFiles = 0;
		try {
			fileos = new FileOutputStream(strZipFileName);
			buffileos = new BufferedOutputStream(fileos);
			zipos = new ZipOutputStream(buffileos);
		
			File fileSourcePath = new File(strSourcePath);
			if (fileSourcePath.isDirectory()) {
				intNumFiles = addDirectoryToZip(strSourcePath, "", zipos);
			} else {
				// Get filename, without path
				int index = strSourcePath.lastIndexOf(File.separator);
				String strFilename = strSourcePath.substring(index + 1);
				addFileToZip(strSourcePath, strFilename, zipos);
				intNumFiles++;
			}
		} catch (IOException e) {
			throw new ServiceException("Exception occurred while creating ZIP file: " + e);
		} finally {
			if (zipos != null) {
				try {
					zipos.flush();
					zipos.close();
				} catch (IOException e) {
					throw new ServiceException("Exception occurred while creating ZIP file: " + e);
				} finally {
					zipos = null;
				}
			}
			if (buffileos != null) {
				try {
					buffileos.flush();
					buffileos.close();
				} catch (IOException e) {
						throw new ServiceException("Exception occurred while creating ZIP file: " + e);
				} finally {
					buffileos = null;
				}
			}
			if (fileos != null) {
				try {
					fileos.flush();
					fileos.close();
				} catch (IOException e) {
					throw new ServiceException("Exception occurred while creating ZIP file: " + e);
				} finally {
					fileos = null;
				}
			}
		}
		
		IDataUtil.put(pc, "numFilesZipped", Integer.toString(intNumFiles));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static int addDirectoryToZip(String strAbsoluteDirectory, String strRelativePath, ZipOutputStream zipos)
	{
		//System.out.println("Absolute directory: " + strAbsoluteDirectory);
		//System.out.println("Relative Path: " + strRelativePath);
		File fileCurrentFile = null;
		int intNumFiles = 0;
	
		File fileSourceDir = new File(strAbsoluteDirectory + "/" + strRelativePath);
	
		// Check if source directory name is valid
		if (!fileSourceDir.exists() || !fileSourceDir.isDirectory())
		{
			Service.throwError("Error reading inbox directory!");
		}
	
		String arrstrSourceDirectoryList[] = fileSourceDir.list();
		int intNumFilesAndDirectories = arrstrSourceDirectoryList.length;
	
		if (intNumFilesAndDirectories < 1)
		{
			//No files to send
			return 0;
		}
	
		//Determine number of actual files
		for (int i = 0; i < intNumFilesAndDirectories; i++)
		{
			String strCurrentFileName = strAbsoluteDirectory + "/" + strRelativePath + "/" + arrstrSourceDirectoryList[i];
			String strCurrentRelativeFileName = null;
			if (strRelativePath == "")
			{
				strCurrentRelativeFileName = arrstrSourceDirectoryList[i];
			}
			else
			{
				strCurrentRelativeFileName = strRelativePath + "/" + arrstrSourceDirectoryList[i];
			}
	
			//System.out.println("currentRelativeFileName: " + strCurrentRelativeFileName);
			//System.out.println("currentFileName: " + strCurrentFileName);
				
			fileCurrentFile = new File(strCurrentFileName);
			if (fileCurrentFile.isDirectory())
			{
				//System.out.println("directory found: " + strCurrentFileName);
				intNumFiles = intNumFiles + addDirectoryToZip(strAbsoluteDirectory, strCurrentRelativeFileName, zipos);
			}
			else //File
			{
				intNumFiles++;
				addFileToZip(strCurrentFileName, strCurrentRelativeFileName, zipos);
			}
		}
	
		fileCurrentFile = null;
		return intNumFiles;
	}
	
	static void addFileToZip(String strCurrentFileName, String strCurrentRelativeFileName, ZipOutputStream zipos)
	{
		FileInputStream fileis = null;
		BufferedInputStream buffileis = null;
		try
		{
			fileis = new FileInputStream(strCurrentFileName);
			buffileis = new BufferedInputStream(fileis);
	
			// Zip File and add to archive
			ZipEntry ze = new ZipEntry(strCurrentRelativeFileName);
			zipos.putNextEntry(ze);
	
			int intNumBytesRead;
			byte data[] = new byte[4096];
			
			while ((intNumBytesRead = buffileis.read(data)) != -1)
			{
				zipos.write(data, 0, intNumBytesRead);
			}
			zipos.closeEntry();
		}
		catch (FileNotFoundException e)
		{
			Service.throwError("Could not open file: " + e);
		}
		catch (IOException e)
		{
			Service.throwError("Could create new zip entry: " + e);
		}
		finally
		{
			if (buffileis != null)
			{
				try
				{
					buffileis.close();
				}
				catch (IOException e)
				{}
			}
			if (fileis != null)
			{
				try
				{ fileis.close(); }
				catch (IOException e)
				{}
			}
		}
	}
	
	private static final boolean checkPathValidity(String strPath, String strAction)
	  throws Exception
	{
		try
		{
			// *** Check if service is on the allowed list ***
			IData in = IDataFactory.create();
			IDataCursor idcIn = in.getCursor();
			idcIn.insertAfter("path", strPath);
			idcIn.insertAfter("action", strAction);
			NSName nsCheckServiceName = NSName.create("PSUtilities.config:checkPathValidity");
			idcIn.destroy();
			IData out;
			out = Service.doInvoke(nsCheckServiceName, in);
			IDataCursor idcOut = out.getCursor();
			String strValid = null;
			if (idcOut.first("valid"))
			{
				strValid = (String)idcOut.getValue();
			}
			idcOut.destroy();
	
			if (strValid.equals("false"))
			{
				return false;
			}
			return true;
			// *** End check ***
		}
		catch (Exception e)
		{
			throw e;
		}
	}
	// --- <<IS-END-SHARED>> ---
}

