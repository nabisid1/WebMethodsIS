package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:23:21 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ServerAPI;
import com.wm.lang.ns.NSName;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class server

{
	// ---( internal utility methods )---

	final static server _instance = new server();

	static server _newInstance() { return new server(); }

	static server _cast(Object o) { return (server)o; }

	// ---( server methods )---




	public static final void getExtendedSettings (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getExtendedSettings)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] record:0:required extended
		IDataCursor pc = pipeline.getCursor();
		
		IData data = null;
		try {
			data = Service.doInvoke(NSName.create("wm.server.query:getExtendedSettings"), IDataFactory.create());
		} catch (Exception e) {}
		
		IDataCursor ic = data.getCursor();
		String ext = IDataUtil.getString(ic, "settings");
		ic.destroy();
		
		Pattern pattern = Pattern.compile("([^\\r\\n]+)");
		Matcher matcher = pattern.matcher(ext);
		data = IDataFactory.create();
		
		ic = data.getCursor();
		while (matcher.find()) {
			String setting = matcher.group();
			IDataUtil.put(ic, setting.substring(0, setting.indexOf("=")), setting.substring(setting.indexOf("=") + 1, setting.length()));
		}
		ic.destroy();
		
		IDataUtil.put(pc, "extended", data);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServerInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required serverName
		// [o] field:0:required serverPort
		// [o] field:0:required serverDir
		// [o] field:0:required serverTempDir
		IDataCursor pc = pipeline.getCursor();
		
		IDataUtil.put(pc, "serverName", ServerAPI.getServerName());
		IDataUtil.put(pc, "serverPort", String.valueOf(ServerAPI.getCurrentPort()));
		IDataUtil.put(pc, "serverDir", getRootDir());
		IDataUtil.put(pc, "serverTempDir", getRootDir() + "pipeline" + File.separator);
		
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServerSettings (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerSettings)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] record:0:required settings
		IDataCursor pc = pipeline.getCursor();
		
		IData data = null;
		try {
			data = Service.doInvoke(NSName.create("wm.server.query:getSettings"), IDataFactory.create());
		} catch (Exception e) {}
		
		IDataUtil.put(pc, "settings", data);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static String getRootDir() {
		String root = ServerAPI.getServerConfigDir().getParent();
		try {
			root = new java.io.File(root).getCanonicalPath() + File.separator;
		} catch (Exception e) {}
		return root;
	}
	// --- <<IS-END-SHARED>> ---
}

