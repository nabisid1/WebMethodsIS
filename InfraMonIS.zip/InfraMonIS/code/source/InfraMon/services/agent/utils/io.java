package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-08-30 10:00:24 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import com.wm.util.coder.*;
import com.wm.data.*;
import com.wm.util.Debug;
import java.net.UnknownHostException;
import com.wm.app.b2b.server.*;
import java.util.Date;
import java.net.InetAddress;
import com.wm.lang.ns.NSName;
import java.text.*;
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class io

{
	// ---( internal utility methods )---

	final static io _instance = new io();

	static io _newInstance() { return new io(); }

	static io _cast(Object o) { return (io)o; }

	// ---( server methods )---




	public static final void deleteFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required deleteStatus
		// [o] field:0:required length
	IDataCursor cursor = pipeline.getCursor();

	String filename = null;
	if (cursor.first("filename"))
	{
		filename = (String) cursor.getValue();
	}
	else
	{
		throw new ServiceException("Input parameter \'filename\' was not found.");
	}
	cursor.destroy();

	File file = new File(filename);
	long len = file.length();
	boolean b = file.delete();

	cursor = pipeline.getCursor();
	cursor.last();
	cursor.insertAfter("deleteStatus", "" + b);
	cursor.insertAfter("length", "" + len);
	cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void readFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required path
		// [i] field:0:required mode {"string","stringlist","bytes","stream"}
		// [i] field:0:optional start
		// [i] field:0:optional length
		// [o] field:0:optional string
		// [o] field:1:optional stringlist
		// [o] object:0:optional bytes
		// [o] object:0:optional stream
		// [o] field:0:optional length
		IDataCursor pc = pipeline.getCursor();
		String path = IDataUtil.getString(pc, "path");
		String mode = IDataUtil.getString(pc, "mode");
		String start = IDataUtil.getString(pc, "start");
		String length = IDataUtil.getString(pc, "length");
		
		int strt = start != null ? new Integer(start).intValue() : 0;
		int len = length != null ? new Integer(length).intValue() : -1;
		
		boolean exists = false;
		try {
			exists = exists(path);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		
		if (path != null && exists) {
			try {
				if (mode.equals("string")) {
					String read = readString(path, strt, len);
					IDataUtil.put(pc, "string", read);
					IDataUtil.put(pc, "length", String.valueOf(read.length()));
				} else if (mode.equals("stringlist")) {	
					String[] read = readLines(path, strt, len);
					IDataUtil.put(pc, "stringlist", read);
					IDataUtil.put(pc, "length", String.valueOf(read.length));
				} else if (mode.equals("bytes")) {
					byte[] read = readBytes(path, strt, len);
					IDataUtil.put(pc, "bytes", read);
					IDataUtil.put(pc, "length", String.valueOf(read.length));
				} else {
					InputStream read = readStream(path);
					IDataUtil.put(pc, "stream", read);
					IDataUtil.put(pc, "length", String.valueOf(read.available()));
				}
			} catch (Exception e) {
				throw new ServiceException(e);
			}
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void writeFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [i] field:0:required message
		// [i] field:0:required append
		// [o] field:0:required error
		IDataCursor iCursor = pipeline.getHashCursor();
		
		// Get configFileName
		iCursor.first( "filename" );
		String	fileName = (String) iCursor.getValue();
		iCursor.first("message");
		String	message = (String) iCursor.getValue();
		iCursor.first("append");
		String	sAppend = (String) iCursor.getValue();
		boolean append = false;
		if (sAppend.compareToIgnoreCase("true") == 0)
			append = true; 
		String error = "OK";
		iCursor.destroy();
		try {
			File f  = new File(fileName);
			if (!f.exists()) {
				FileWriter fw = new FileWriter(fileName, false);
				fw.write(message + "\n\r" );
				fw.flush();
				fw.close();
			} else if (!f.canWrite()) {
				error = "File is not writable";
			} else if (!f.isFile()) {
				error = "File is not normal file";
			} else {
				FileWriter fw = new FileWriter(fileName, append);
				fw.write(message + "\n\r" );
				fw.flush();
				fw.close();
			} 
		} catch (Exception e) {
				error = e.toString();
		} finally {
			IDataHashCursor pipelineCursor_1 = pipeline.getHashCursor();
			pipelineCursor_1.last();
			pipelineCursor_1.insertAfter( "error", "" + error );
			
		pipelineCursor_1.destroy();
		}
		 
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static boolean exists(String path)
		throws Exception {
		boolean exists = false;
		File file = new File(path);
		return file.exists() && (file.isFile() || file.isDirectory());
	}
	
	public static long writeAfter(InputStream stream, String path, int maxSize)
		throws Exception {
		return write(null, stream, path, true, maxSize);
	}
	
	public static long writeBefore(InputStream stream, String path, int maxSize)
		throws Exception {
		byte[] bytes = readBytes(path, 0, maxSize);
		return write(new ByteArrayInputStream(bytes), stream, path, false, maxSize);
	}
	
	public static long writeOver(InputStream stream, String path, int maxSize)
		throws Exception {
		return write(null, stream, path, false, maxSize);
	}
	
	public static long write(InputStream afterStream, InputStream beforeStream, String path, boolean append, int maxSize)
		throws Exception {
		if (!exists(getParent(path))) {
			throw new IOException();
		}
	
		FileOutputStream fout = new FileOutputStream(path, append);
		int pos = 0;
		int read = 0;
		byte[] buffer = new byte[8192];
		
		while ((read = beforeStream.read(buffer, 0, buffer.length)) > 0 && (pos < maxSize || maxSize == -1)) {
			fout.write(buffer, 0, read);
			pos += read;
		}
		beforeStream.close();
	
		int pos2 = pos;
		if (afterStream != null && afterStream.available() > 0) {
			while ((read = afterStream.read(buffer, 0, buffer.length)) > 0 && (pos2 < maxSize || maxSize == -1)) {
				fout.write(buffer, 0, read);
				pos2 += read;
			}
			afterStream.close();
		}
	
		fout.flush();
		fout.close();
		return pos;
	}
	
	public static String readString(String path, int start, int length)
		throws Exception {
		return new String(readBytes(path, start, length));
	}
	
	public static String[] readLines(String path, int start, int length)
		throws Exception {
		if (!exists(path)) {
			return new String[0];
		}
	
		ArrayList content = new ArrayList();
		BufferedReader in = new BufferedReader(new FileReader(path));
		String line = "";
		long ln = 0;
		while ((line = in.readLine()) != null) {
			if (ln >= start) {
				content.add(line);
				if (length > 0 && start + ln >= length) {
					break;
				}
			}
			ln++;
		}
		in.close();
		return (String[])content.toArray(new String[0]);
	}
	
	public static byte[] readBytes(String path, int start, int length)
		throws Exception {
		if (!exists(path)) {
			return new byte[0];
		}
	
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		FileInputStream fin = (FileInputStream)readStream(path);
		int pos = start;
		int read = 0;
		byte[] buffer = new byte[8192];
		while ((read = fin.read(buffer, 0, buffer.length)) > 0 && (pos < length || length == -1)) {
			bout.write(buffer, 0, read);
			pos += read;
		}
		bout.flush();
	
		byte[] bytes = bout.toByteArray();
		bout.close();
		return bytes;
	}
	
	public static InputStream readStream(String path)
		throws Exception {
		return new FileInputStream(path);
	}
	
	public static long size(String filename)
		throws Exception {
		return new File(filename).length();
	}
	
	public static String getName(String path)
		throws Exception {
		if (path.lastIndexOf(File.separator) >= 0) {
			path = path.substring(path.lastIndexOf(File.separator) + 1, path.length());
		}
		return path;
	}
	
	public static String getParent(String path)
		throws Exception {
		return new File(path).getParentFile().getCanonicalPath();
	}
	// --- <<IS-END-SHARED>> ---
}

