package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:23:24 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.ns.NSName;
// --- <<IS-END-IMPORTS>> ---

public final class service

{
	// ---( internal utility methods )---

	final static service _instance = new service();

	static service _newInstance() { return new service(); }

	static service _cast(Object o) { return (service)o; }

	// ---( server methods )---




	public static final void doThreadedInvoke (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(doThreadedInvoke)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [i] record:0:required input
		// [o] field:0:required status
		IDataCursor pc = pipeline.getCursor();
		String service = IDataUtil.getString(pc, "serviceName");
		IData input = IDataUtil.getIData(pc, "input");
		
		boolean invoked = true;
		try {
			NSName nsname = NSName.create(service);
			Service.doThreadInvoke(nsname, input, 2000);
		} catch (Exception e) {
			invoked = false;
		}
		
		IDataUtil.put(pc, "status", String.valueOf(invoked));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}
}

