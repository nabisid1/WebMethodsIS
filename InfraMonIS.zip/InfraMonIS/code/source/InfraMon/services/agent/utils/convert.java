package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:22:30 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class convert

{
	// ---( internal utility methods )---

	final static convert _instance = new convert();

	static convert _newInstance() { return new convert(); }

	static convert _cast(Object o) { return (convert)o; }

	// ---( server methods )---




	public static final void anyToString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(anyToString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required any
		// [o] field:0:required string
		IDataCursor pc = pipeline.getCursor();
		Object any = IDataUtil.get(pc, "any");
		
		String string = null;
		if (any != null) {
			string = any.toString();
		}
		
		IDataUtil.put(pc, "string", string);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void stringListToString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringListToString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required stringList
		// [i] field:0:optional separator
		// [o] field:0:required string
		IDataCursor pc = pipeline.getCursor();
		
		String[] list = IDataUtil.getStringArray(pc, "stringList");
		String sep = IDataUtil.getString(pc, "separator");
		
		if (sep == null) {
			sep = ",  ";
		}
		
		StringBuffer buffer = new StringBuffer();
		String separator = "";
		if (list != null) {
			for (int i = 0; i < list.length; i++) {
				buffer.append(separator).append(list[i]);
				if (i == 0) { 
					separator = sep;
				}
			}
		}
		
		IDataUtil.put(pc, "string", buffer.toString());
		pc.destroy();
		// --- <<IS-END>> ---

                
	}
}

