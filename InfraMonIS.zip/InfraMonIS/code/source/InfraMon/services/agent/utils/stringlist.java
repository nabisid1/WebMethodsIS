package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:23:31 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class stringlist

{
	// ---( internal utility methods )---

	final static stringlist _instance = new stringlist();

	static stringlist _newInstance() { return new stringlist(); }

	static stringlist _cast(Object o) { return (stringlist)o; }

	// ---( server methods )---




	public static final void append (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(append)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required list
		// [i] field:0:required element
		// [o] field:1:required list
		IDataCursor pc = pipeline.getCursor();
		String[] list = IDataUtil.getStringArray(pc, "list");
		String element = IDataUtil.getString(pc, "element");
		
		ArrayList alist = null;
		if (list == null || list.length == 0) {
			alist = new ArrayList();
		} else {
			alist = new ArrayList(Arrays.asList(list));
		}
		if (element != null) {
			alist.add(element);
		}
		
		IDataUtil.put(pc, "list", (String[])alist.toArray(new String[0]));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void contains (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(contains)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required list
		// [i] field:0:required element
		// [o] field:0:required contains
		IDataCursor pc = pipeline.getCursor();
		String[] list = IDataUtil.getStringArray(pc, "list");
		String element = IDataUtil.getString(pc, "element");
		
		boolean contains = new ArrayList(Arrays.asList(list)).contains(element);
		
		IDataUtil.put(pc, "contains", String.valueOf(contains));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}
}

