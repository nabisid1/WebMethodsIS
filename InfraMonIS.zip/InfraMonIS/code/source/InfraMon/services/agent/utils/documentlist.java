package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:22:50 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
import java.lang.*;
import com.wm.data.*;
import java.util.zip.CRC32;
import java.math.BigDecimal;
// --- <<IS-END-IMPORTS>> ---

public final class documentlist

{
	// ---( internal utility methods )---

	final static documentlist _instance = new documentlist();

	static documentlist _newInstance() { return new documentlist(); }

	static documentlist _cast(Object o) { return (documentlist)o; }

	// ---( server methods )---




	public static final void append (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(append)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required list1
		// [i] record:1:required list2
		// [o] record:1:required list
		IDataCursor pc = pipeline.getCursor();
		
		IData[] list1 = IDataUtil.getIDataArray(pc, "list1");
		IData[] list2 = IDataUtil.getIDataArray(pc, "list2");
		
		IData[] combined = null;
		if (list1 != null) {
			combined = list1;
		}
		if (list2 != null) {
			if (combined != null) {
				ArrayList listA = new ArrayList(Arrays.asList(list1));
				ArrayList listB = new ArrayList(Arrays.asList(list2));
				listA.addAll(listB);
				combined = (IData[])listA.toArray(new IData[0]);
			} else {
				combined = list2;
			}
		}
		
		IDataUtil.put(pc, "list", combined);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void filter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(filter)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:optional documentList
		// [i] field:0:required propertyName
		// [i] field:0:required propertyValue
		// [i] field:0:optional equals {"true","false"}
		// [i] field:0:optional pattern {"false","true"}
		// [i] field:0:optional bothLists {"false","true"}
		// [i] field:0:optional ignoreCase {"false","true"}
		// [o] record:1:optional filteredDocumentList
		// [o] record:1:optional filteredOutDocumentList
		IDataCursor pc = pipeline.getCursor();
		IData[] documentList = IDataUtil.getIDataArray(pc, "documentList");
		String sKey = IDataUtil.getString(pc, "propertyName");
		String sValue = IDataUtil.getString(pc, "propertyValue");
		String sEquals = IDataUtil.getString(pc, "equals");
		String sPattern = IDataUtil.getString(pc, "pattern");
		String sBothLists = IDataUtil.getString(pc, "bothLists");
		String sIgnoreCase = IDataUtil.getString(pc, "ignoreCase");
		
		boolean equals = sEquals != null && sEquals.equals("true");
		boolean like   = sPattern != null && sPattern.equals("true");
		boolean bothLists = sBothLists != null && sBothLists.equals("true");
		boolean ignoreCase = sIgnoreCase != null && sIgnoreCase.equals("true");
		ArrayList list = new ArrayList();
		ArrayList list2 = new ArrayList();
		
		// filter
		String restKey1 = sKey;
		if (sKey.indexOf("/") > 1) {
			restKey1 = sKey.substring(sKey.indexOf("/") + 1, sKey.length());
		}
		
		if (sValue != null && ignoreCase) {
			sValue = sValue.toLowerCase();
		}
		
		for (int i = 0; documentList != null && i < documentList.length; i++) {
			String value = getKeyValue(documentList[i], restKey1);
			if (value == null) {
				value = "";
			}
			if (ignoreCase) {
				value = value.toLowerCase();
			}
			if (equals) {
				if (sValue.equals(value)) {
					list.add(documentList[i]);
				} else if (like && value.indexOf(sValue) >= 0) {
					list.add(documentList[i]);
				} else if (bothLists) {
					list2.add(documentList[i]);
				}
			} else {
				if (!sValue.equals(value)) {
					list.add(documentList[i]);
				} else if (bothLists) {
					list2.add(documentList[i]);
				}
			}
		}
		
		if (list.size() > 0) {
			IDataUtil.put(pc, "filteredDocumentList", (IData[])list.toArray(new IData[0]));
		} else {
			IDataUtil.put(pc, "filteredDocumentList", null);
		}
		
		if (bothLists) {	
			if (list2.size() > 0) {
				IDataUtil.put(pc, "filteredOutDocumentList", (IData[])list2.toArray(new IData[0]));
			} else {
				IDataUtil.put(pc, "filteredOutDocumentList", null);
			}
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static IData getKeyDocument(IData itemData, String itemName) {
		if (itemData==null)	return null;
		IDataCursor cursor = itemData.getCursor();
		IData result = null;
	
		if (itemName.indexOf("/") > 0) {
			String nextItemName = itemName.substring(0, itemName.indexOf("/"));
			IData nextItemData = IDataUtil.getIData(cursor, nextItemName);
			if (nextItemData != null) {
				result = getKeyDocument(nextItemData, itemName.substring(itemName.indexOf("/") + 1, itemName.length()));
			}
		} else {
			result = IDataUtil.getIData(cursor, itemName);
		}	
		cursor.destroy();
		return result;
	}
	
	public static String getKeyValue(IData itemData, String itemName) {
		if (itemData==null)	return "";
		IDataCursor cursor = itemData.getCursor();
		String result = "";
	
		if (itemName.indexOf("/") > 0) {
			String nextItemName = itemName.substring(0, itemName.indexOf("/"));
			IData nextItemData = IDataUtil.getIData(cursor, nextItemName);
			if (nextItemData != null)
				result = getKeyValue(nextItemData, itemName.substring(itemName.indexOf("/") + 1, itemName.length()));
		} else {
			result = IDataUtil.getString(cursor, itemName);
		}
		cursor.destroy();
		if (result==null)	result="";
		return result;
	}
	
	public static IData setKeyValue(IData itemData, String itemName, Object itemValue, String delimiter) {
		if (itemData == null) {
			itemData = IDataFactory.create();
		}
		IDataCursor cursor = itemData.getCursor();
	
		if (delimiter!=null && itemName.indexOf(delimiter) > 0) {
			String nextItemName = itemName.substring(0, itemName.indexOf(delimiter));
			IData nextItemData = IDataUtil.getIData(cursor, nextItemName);
			nextItemData = setKeyValue(nextItemData, itemName.substring(itemName.indexOf(delimiter) + delimiter.length(), itemName.length()), itemValue, delimiter);
			IDataUtil.put(cursor, nextItemName, nextItemData);
		} else {
			IDataUtil.put(cursor, itemName, itemValue);
		}	
		cursor.destroy();
		return itemData;
	}
	
	public static class ComparableDocument implements Comparable {
		private IData document = null;
		private String[] keys = null;
		private boolean ascending = true;
		private boolean _ignoreCase = true;
		private boolean _numeric = false;
	
		public ComparableDocument(IData document, String[] keys, boolean ascending, boolean ignoreCase) {
			this.document = document;
			this.keys = keys;
			this.ascending = ascending;
			this._ignoreCase = ignoreCase;
			this._numeric = false;
		}
	
		public ComparableDocument(IData document, String[] keys, boolean ascending, boolean ignoreCase, boolean numeric) {
			this.document = document;
			this.keys = keys;
			this.ascending = ascending;
			this._ignoreCase = ignoreCase;
			this._numeric = numeric;
		}
	
		public int compareTo(IData idata) {
			int result = 0;
			try {
				for (int i = 0; i < this.keys.length && result == 0; i++) {
					String keyA = getKeyValue(this.document, keys[i]);
					String keyB = getKeyValue(idata, keys[i]);
					if (_numeric && isNumeric(keyA) && isNumeric(keyB)) {
						BigDecimal bdA = new BigDecimal(keyA);
						BigDecimal bdB = new BigDecimal(keyB);
						result = bdA.compareTo(bdB);
					} else if (_ignoreCase) {
						result = keyA.compareToIgnoreCase(keyB);
					} else {
						result = keyA.compareTo(keyB);
					}
				}
			}
			catch (Exception e) {}
			// this is required to allow consistent reordering of the tree
			// plus objects may never be the same
			if (result==0) {
				result = document.hashCode()>idata.hashCode() ? -1 : 1;
			}
	
			if (!this.ascending) {
				result = result * -1;
			}
			return result;
		}
	
		public int compareTo(ComparableDocument cd) {
			return compareTo(cd.getDocument());
		}
	
		public int compareTo(Object o) {
			return compareTo((ComparableDocument)o);
		}
	
		public IData getDocument() {
			return this.document;
		}
	
		public boolean equals(Object o) {
			return compareTo(o) == 0;
		}
	
		private boolean isNumeric (String value) {
			boolean result = false;
			try {
				BigDecimal big = new BigDecimal(value);
				result = true;
			} catch (Exception e) {}
			return result;
		}
	}
	
	
	public static class DocumentComparator implements Comparator {
		private boolean ascending = true;
	
		public DocumentComparator(boolean ascending) {
			this.ascending = ascending;
		}
	
		public int compare(Object a, Object b) {
			ComparableDocument xa = (ComparableDocument)a;
			ComparableDocument xb = (ComparableDocument)b;
			int result = 0;
			try {
				result = xa.compareTo(xb);
			} catch (Exception e) {}
			return result;
		}
	
		public boolean equals(Object a, Object b) {
			return compare(a, b) == 0;
		}
	}
	
	public static long getCRCFromObject(Object object) {
		long crc = 0;
		try {
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			ObjectOutputStream out = new ObjectOutputStream(bout);
			out.writeObject(object);
			CRC32 crc32 = new CRC32();
			crc32.update(bout.toByteArray());
			crc = crc32.getValue();
			out.close();
			bout.close();
		} catch (Exception e) {}
		return crc;
	}
	
	public static ArrayList arrayToList(IData[] array) {
		ArrayList result = null;
		if (array != null ) {
			result = new ArrayList(Arrays.asList(array));
		}
		return result;
	}
	
	public static IData[] listToArray(ArrayList list) {
		IData[] result = null;
		if (list != null) {
			result = (IData[])list.toArray(new IData[0]);
		}
		return result;
	}
	
	/** Matches two string arrays of equal length.
	 * Nr of matches is recorded as well as at what index
	 * this occurred.
	 * @param values1 Input string list
	 * @param values2 Input string list 2
	 * @return An IData object with a 'match' indicator and an ArrayList with matching indexes
	 */
	private static IData match(String [] values1, String[] values2, String type) {
		
		int nrOfMatches = 0;   // Set up counter
		
		IData result = IDataFactory.create();  			// Create the IData for returning
		IDataCursor rc = result.getCursor();   			// plus a cursor on it
		ArrayList matchingFieldNrs = new ArrayList();   // Setup an empty ArrayList for the matching indexes
	
		// loop over the various values
		for (int i = 0 ; i < values1.length ; i ++) {
				
			// Note that if one or both of the strings is null, it's regarded as non-matching
			if (values1[i] != null && values2[i] != null && values1[i].equals(values2[i])) {
				nrOfMatches++;
				matchingFieldNrs.add(new MInteger(i));  // record the index at which the match occurred
			}
		}
		
		if ( (type.equals("AND") && nrOfMatches == values1.length) || (type.equals("OR") && nrOfMatches > 0) ||
			 (type.equals("XOR") && nrOfMatches == 1) 				) {
				rc.insertAfter("matches", new MBoolean(true));
				rc.insertAfter("matchingFieldNrs", matchingFieldNrs );
		} else {
			rc.insertAfter("matches", new MBoolean(false));
		}
		
		rc.destroy();
		return result;
	}
	
	// -1, 0 or 1(v2>v1)
	private static int match(String [] values1, String[] values2) {
		for (int i=0 ; i<values1.length && i<values2.length ; i++) {
			if (values1[i]==null) {
				if (values2[i]!=null) {
					return 1;
				}
			} else if (values2[i]==null) {
				return -1;
			} else {
				int r = values1[i].compareTo(values2[i]); // -1 when v1<v2
				if (r>0)	return -1;	// v1>v2
				if (r<0)	return 1;	// v1<v2
			}
		}
		if (values1.length>values2.length)		return -1;
		if (values1.length<values2.length)		return 1;
		return 0;
	}
	
	
	public static class IDataBuffer {
	    
	    /** Creates a new instance of IDataBuffer */
	    public IDataBuffer() {
	        iBuffer = new IData[INITIAL_SIZE];
	        capacity = iBuffer.length;
	        lastElementPtr = -1;
	    }
	    
	    /** Initializes the buffer with the passed IData object
	     * @param element IData object
	     */
	    public IDataBuffer(IData element) {
	        iBuffer = new IData[INITIAL_SIZE];
	        iBuffer[0] = element;
	        capacity = iBuffer.length;
	        lastElementPtr = -1;
	    }
	    
	    /** Initializes the buffer with a buffer array of the given size
	     * @param initialCapacity Size the buffer will initially be set to
	     */
	    public IDataBuffer(int initialCapacity) {
	        iBuffer = new IData[initialCapacity];
	        capacity = initialCapacity;
	        lastElementPtr = -1;
	    }
	    
	    /** Initializes the buffer with the passed IData object and
	     * sets the initial capacity of the buffer
	     * @param element The IData object the buffer will initialized with
	     * @param initialCapacity Initial size of the buffer
	     */    
	    public IDataBuffer(IData element, int initialCapacity) {
	        iBuffer = new IData[initialCapacity];
	        iBuffer[0] = element;
	        capacity = initialCapacity;
	        lastElementPtr = 0;
	        
	        
	    }
	    
	    /** Size the buffer will initially be set to */
	    public static final int INITIAL_SIZE = 16;
	    
	    /** The internal array of type IData that will act as the buffer */    
	    private IData [] iBuffer;
	    
	    int capacity;
	    
	    int lastElementPtr;
	    
	    /** Whenever this method is called, the size of the buffer
	     * is doubled
	     */    
	    private void growCapacity() {
	        if (capacity == 0)
	            capacity = 1;
	        int newCapacity = capacity * 2;
	        IData [] newIBuffer = new IData[newCapacity ];
	        //System.arraycopy(iBuffer, 0, newIBuffer, 0, iBuffer.length);
			for (int i=0 ; i < iBuffer.length; i++ ) {
				newIBuffer[i] = iBuffer[i];
			}
	        iBuffer = newIBuffer;
	        capacity = newCapacity;
	    }
	    
	    /** Calls <CODE>growCapacity()</CODE> as many times as necessary
	     * in order to make sure that <CODE>newCapacity</CODE> will fit
	     * into the buffer
	     * @param newCapacity The minimum the size the buffer should be able
	     * to contain
	     */    
	    private void ensureCapacity(int newCapacity) {
	        while (capacity < newCapacity)
	            growCapacity();
	        
	    }
	    
	    /** Appends an IData object to the existing array
	     * @param element The IData object to be added
	     * @return A reference to the buffer
	     */
	    public IDataBuffer append(IData element) {
	        
	        if ((++lastElementPtr)>= capacity )
	            growCapacity();
	        iBuffer[lastElementPtr] = element;
	        return this;
	    }
	    
	    /** Appends an IData object array to the buffer
	     * @param elements Array of IData objects to be added
	     * @return Returns a reference to the buffer
	     */
	    public IDataBuffer append(IData [] elements) {
	        
	        
	        ensureCapacity(lastElementPtr + elements.length + 1);
	        
	        for (int i = 0 ; i < elements.length ; i++) {
	
	            iBuffer[++lastElementPtr ] = elements[i];
	            
	        }
	        //lastElementPtr = lastElementPtr + elements.length;
	        return this;
	    }
	    
	    /** Returns a trimmed and indepenedent array the elements currently in the buffer
	     * @return IData array
	     */
	    public IData [] toArray() {
	        
	        IData[] retArray = new IData[lastElementPtr+1];
	        //System.arraycopy(iBuffer, 0, retArray, 0, retArray.length);
			for (int i=0 ; i < retArray.length; i++ ) {
				retArray[i] = iBuffer[i];
			}
	        return retArray;
	    }
	}
	
	/**
	* This method trims a string in an IData object 'in loco'
	* Depending on the parameter 'recursive', the same method
	* is called each time an IData object is encountered
	*/
		
	private static void trim(IData doc, boolean recursive) 
	{
		IDataCursor udc = doc.getCursor();
		if (	udc.first() ) {
		
			do {
			   Object o = udc.getValue();
				   
	   		   if (o instanceof String) {
					udc.setValue(((String) o).trim() );
						
			   }
			   // If an IData object is encountered and recursive mode is on
	           // call this method again
		
	   		   if (o instanceof IData && recursive) {
					trim((IData) o);				
			   }	
	   		   if (o instanceof IData [] && recursive) {
				IData [] docArray = (IData [] ) o;
				for (int i = 0 ; i < docArray.length ; i++ ) {
					trim(docArray[i]);		
				}		
			   }	
	
						
			}	
			while (udc.next() );
		
			}
		udc.destroy();
	}
	
	private static void trimNull(IData doc, boolean recursive) 
	{
		IDataCursor udc = doc.getCursor();
		if (	udc.first() ) 
		{
			do 
			{
				Object o = udc.getValue();
				if (o==null)
					;// do nothing
				else if (o instanceof String) 
				{
					String v = ((String)o).trim();
					if (v.length()>0)
						udc.setValue(v);
					else
						udc.setValue(null);
				}
				// If an IData object is encountered and recursive mode is on
				// call this method again
				else if (recursive)
				{
					if (o instanceof IData ) 
						trimNull((IData) o, recursive);				
					else if (o instanceof IData []) 
					{
						IData [] docArray = (IData [] ) o;
						for (int i = 0 ; i < docArray.length ; i++ ) 
							trimNull(docArray[i], recursive);		
					}	
				}
			}	
			while (udc.next() );
		
		}
		udc.destroy();
	}
	
	/**
	* Convenience method. Calls 'trim' in non-recursive mode
	*/
		
	private static void trim(IData doc) {
		trim(doc, false);
	}
	
	
	static IData[] sortDocumentList( IData[] list, String[] keys,boolean ascending, boolean ignoreCase)
	{
		if (list != null && keys != null)
		{
			TreeSet sorted = new TreeSet(new documentlist.DocumentComparator(ascending));
			for (int i = 0; i < list.length; i++)
				sorted.add(new ComparableDocument(list[i], keys, ascending, ignoreCase));
	
			int i = 0;
			Iterator iterator = sorted.iterator();
			list = new IData[sorted.size()];
			while (iterator.hasNext())
			{
				list[i++] = ((ComparableDocument)iterator.next()).getDocument();
			}
		}
		return list;
	}
	
	static IData[] sortDocumentList( IData[] list, String[] keys,boolean ascending, boolean ignoreCase, boolean numeric)
	{
		if (list != null && keys != null)
		{
			TreeSet sorted = new TreeSet(new documentlist.DocumentComparator(ascending));
			for (int i = 0; i < list.length; i++)
				sorted.add(new ComparableDocument(list[i], keys, ascending, ignoreCase, numeric));
	
			int i = 0;
			Iterator iterator = sorted.iterator();
			list = new IData[sorted.size()];
			while (iterator.hasNext())
			{
				list[i++] = ((ComparableDocument)iterator.next()).getDocument();
			}
		}
		return list;
	}
	// --- <<IS-END-SHARED>> ---
}

