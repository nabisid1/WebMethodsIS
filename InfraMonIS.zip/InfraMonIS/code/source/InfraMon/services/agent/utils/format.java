package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:22:58 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class format

{
	// ---( internal utility methods )---

	final static format _instance = new format();

	static format _newInstance() { return new format(); }

	static format _cast(Object o) { return (format)o; }

	// ---( server methods )---




	public static final void documentToHtml (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(documentToHtml)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional title
		// [i] record:0:required document
		// [i] field:0:optional tocLevel
		// [i] field:0:optional startAtLevel
		// [o] field:1:required toc
		// [o] field:0:required html
		
		IDataCursor pc = pipeline.getCursor();
		IData document = IDataUtil.getIData(pc, "document");
		String title = IDataUtil.getString(pc, "title");
		String tocLevel = IDataUtil.getString(pc, "tocLevel");
		String startLevel = IDataUtil.getString(pc, "startAtLevel");
		
		if (title == null) {
			title = "Document";
		}
		
		int levelToc = 0;
		try {
			levelToc = Integer.parseInt(tocLevel);
		} catch (Exception e) {}
		
		int startAt = 0;
		try {
			startAt = Integer.parseInt(startLevel);
		} catch (Exception e) {}
		
		StringBuffer buffer = new StringBuffer();
		ArrayList index = new ArrayList();
		//addTitle(index, "", "Table of contents");
		parseDocument(buffer, new Stack(), new String(), title, document, PIVOT_LIST, index, levelToc, startAt);
		
		IDataUtil.put(pc, "html", buffer.toString());
		IDataUtil.put(pc, "toc", (String[])index.toArray(new String[0]));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void listNumbers (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listNumbers)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required start
		// [i] field:0:required end
		// [o] field:1:required list
		
		IDataCursor pc = pipeline.getCursor();
		String start = IDataUtil.getString(pc, "start");
		String end = IDataUtil.getString(pc, "end");
		
		int ss = 0;
		int ee = 0;
		try {
			ss = Integer.parseInt(start);
		} catch (Exception e) {}
		try {
			ee = Integer.parseInt(end);
		} catch (Exception e) {}
		
		String[] list = new String[ee - ss + 1];
		for (int i = 0; i < list.length; i++) {
			list[i] = String.valueOf(ss + i);
		}
		
		IDataUtil.put(pc, "list", list);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void listToTable (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listToTable)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required list
		// [i] field:0:required width
		// [i] field:0:required separator
		// [o] field:1:required rows
		IDataCursor pc = pipeline.getCursor();
		
		String[] list = IDataUtil.getStringArray(pc, "list");
		String width = IDataUtil.getString(pc, "width");
		String sep = IDataUtil.getString(pc, "separator");
		
		if (sep == null) {
			sep = ",  ";
		}
		
		int cols = 1;
		try {
			cols = Integer.parseInt(width);
		} catch (Exception e) {}
		
		ArrayList rows = new ArrayList();
		for (int i = 0; list != null && i < list.length; i++) {
			String row = new String();
			String separator = "";
			for (int j = 0; j < cols && (i + j) < list.length; j++) {
				row = row.concat(separator).concat(list[i + j]);
				if (j == 0) { 
					separator = sep;
				}
			}
			rows.add(row);
			i += cols - 1;	
		}
		
		IDataUtil.put(pc, "rows", (String[])rows.toArray(new String[0]));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	// ----- PARSER FUNCTIONS -----
	public static void parseDocument(StringBuffer buffer, Stack typeStack, String nextRoot, String nextName, 
			IData nextData, int pivot, ArrayList index, int levelToc, int startAt) {
	
		try {
		String parent = null;
		boolean isPivot = false;
	
		if (pivot > PIVOT_NONE && typeStack.size() > 0 ) {
			parent = (String)typeStack.peek();
			isPivot = (parent != null && pivot > PIVOT_NONE && parent.equals(TYPE_LIST));
		}
	
		if (!isPivot) {
			if (typeStack.size() >= startAt) {
				if (typeStack.size() <= levelToc) {
					index.add("<a nowrap class='toc' href='#" + nextRoot + "/" + nextName + "'>" + nextName + "</a>");
				}
				startDocument(buffer, typeStack, nextRoot, nextName, nextData, isPivot, startAt);
			}
		} else {
			startPivotRow(buffer);
		}
	
		IDataCursor ic = nextData.getCursor();
		while (ic.next()) {
			String subRoot = nextRoot.concat("/").concat(nextName);
			String subName = ic.getKey();
			Object subObjt = ic.getValue();
			
			if (subName == null) {
				subName = new String("Unnamed");
			}
	
			if (subObjt instanceof IData) {
				typeStack.push(TYPE_DOC);
				if (subObjt != null) {
					parseDocument(buffer, typeStack, subRoot, subName, (IData)subObjt, pivot, index, levelToc, startAt);
				} else {
					parseString(buffer, typeStack, subRoot, subName, "(empty document)", isPivot);
				}
				typeStack.pop();
			} else if (subObjt instanceof IData[]) {
				typeStack.push(TYPE_LIST);
				IData[] subList = (IData[])subObjt;
				if (subList.length > 0) {
					parseDocumentList(buffer, typeStack, subRoot, subName, subList, pivot, index, levelToc, startAt);
				} else {
					parseString(buffer, typeStack, subRoot, subName, "(empty documentlist)", isPivot);
				}
				typeStack.pop();
			} else if (subObjt instanceof String) {
				if (subObjt.toString().trim().equals("")) {
					parseString(buffer, typeStack, subRoot, subName, "(empty string)", isPivot);
				} else {
					parseString(buffer, typeStack, subRoot, subName, (String)subObjt, isPivot);
				}
			} else if (subObjt instanceof String[]) {
				String[] subList = (String[])subObjt;
				if (subList.length > 0) {
					parseStringList(buffer, typeStack, subRoot, subName, (String[])subObjt, isPivot);
				} else {
					parseString(buffer, typeStack, subRoot, subName, "(empty stringlist)", isPivot);
				}
			} else if (subObjt == null) {
				parseString(buffer, typeStack, subRoot, subName, "(null)", isPivot);
			} else {
				parseString(buffer, typeStack, subRoot, subName, subObjt.toString(), isPivot);
			}
		}
	
		if (!isPivot) { 
			if (typeStack.size() >= startAt) {
				endDocument(buffer, typeStack, isPivot, startAt);
			}
		} else {
			endPivotRow(buffer);
		}
	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void parseDocumentList(StringBuffer buffer, Stack typeStack, String nextRoot, String nextName, 
			IData[] nextList, int pivot, ArrayList index, int levelToc, int startAt) {
	
		boolean isPivot = (pivot == PIVOT_LIST);
	
		if (typeStack.size() >= startAt && typeStack.size() <= levelToc) {
			index.add("<a nowrap class='toc' href='#" + nextRoot + "/" + nextName + "'>" + nextName + "</a>");
		}
	
		startDocument(buffer, typeStack, nextRoot, nextName, nextList[0], isPivot, startAt);
		for (int i = 0; i < nextList.length; i++) {
			parseDocument(buffer, typeStack, nextRoot, nextName + "[" + i + "]", nextList[i], pivot, index, levelToc, startAt);
		}
		endDocument(buffer, typeStack, isPivot, startAt);
	}
	
	public static void parseStringList(StringBuffer buffer, Stack typeStack, String nextRoot, String nextName, 
			String[] nextList, boolean isPivot) {
	
		for (int i = 0; i < nextList.length; i++) {
			parseString(buffer, typeStack, nextRoot, nextName, nextList[i], isPivot);
		}
	}
	
	public static void parseString(StringBuffer buffer, Stack typeStack, String nextRoot, String nextName, 
			String nextValue, boolean isPivot) {
	
		String parent = (typeStack.size() > 0) ? (String)typeStack.peek() : null;
		if (isPivot) {
			// Pivotting fields in a document or document list
			buffer.append("<td nowrap class='evenrowdata-l'>").append(nextValue).append("</td>");
		} else {
			String wrap = (nextValue.length() < 50) ? "nowrap" : "";
			buffer.append("<tr><td width='1%' nowrap class='evenrowdata-l'>").append(nextName).append("</td>")
				  .append("<td ").append(wrap).append(" class='evenrowdata-l'>")
				  .append(nextValue).append("</td></tr>\n");
		}
	}
	
	// ----- HANDLER FUNCTIONS -----
	public static void startDocument(StringBuffer buffer, Stack typeStack, String nextRoot, String nextName, 
			IData nextData, boolean isPivot, int startAt) {
	
		// If subdocument, enclose in cell
		if (typeStack.size() > startAt) {
			if (typeStack.subList(0, typeStack.size() - 1).contains(TYPE_LIST)) {
				buffer.append("<td nowrap>\n");
			} else {
				buffer.append("<tr><td nowrap class='oddrow-l'> </td><td nowrap>\n");
			}
		}
	
		// Add floating title in separate table
		addTitle(buffer, nextRoot, nextName);
	
		// Start new table; if subdocument, no width
		if (typeStack.size() > startAt) {
			buffer.append("<table class='tableView'>\n");
		} else {
			buffer.append("<table width='100%' class='tableView'>\n");
		}
	
		// Add header
		if (isPivot) {
			addPivotHeader(buffer, nextData);
		} else { 
			addTableHeader(buffer);
		}
	}
	
	public static void endDocument(StringBuffer buffer, Stack typeStack, boolean isPivot, int startAt) {
	
		// Close table
		buffer.append("</table>\n");
	
		// If subdocument, close containing cell
		if (typeStack.size() > startAt) {
			if (typeStack.subList(0, typeStack.size() - 1).contains(TYPE_LIST)) {
				buffer.append("</td>");
			} else {
				buffer.append("</td></tr>");
			}
		}
	}
	
	public static void startPivotRow(StringBuffer buffer) {
	
		buffer.append("<tr>\n");
	}
	
	public static void endPivotRow(StringBuffer buffer) {
	
		buffer.append("</tr>\n");
	}
	
	private static void addTitle(StringBuffer buffer, String nextRoot, String title) {
		buffer.append("<a name='").append(nextRoot).append("/").append(title).append("'></a><br>")
		      .append("<table class='tableView' width='100%' cellspacing='0' cellpadding='2' border='0'>\n")
			  .append("<tr><td width='50' align='left' class='heading'><a class='toplink' href='#top'>top</a></td>\n")
			  .append("<td nowrap class='heading'>").append(title).append("</td></tr>")
			  .append("</table>\n");
	}
	
	private static void addTableHeader(StringBuffer buffer) {
		buffer.append("<tr> <td nowrap class='oddrow-l'><b> Name </b></td><td nowrap class='oddcol-l'><b> Value </b></td></tr>\n");
	}
	
	private static void addPivotHeader(StringBuffer buffer, IData nextData) {
		buffer.append("<tr>");
		IDataCursor ic = nextData.getCursor();
		while (ic.next()) {
			buffer.append("<td nowrap class='oddcol-l'><b>").append(ic.getKey()).append("</b></td>\n");
		}
		buffer.append("</tr>");
		ic.destroy();
	}
	
	private static final int ROW_VALUE     = 0;
	private static final int ROW_CONTAINER = 1;
	private static final int ROW_DEFAULT   = 999;
	
	private static final int PIVOT_NONE    = 0;
	private static final int PIVOT_LIST    = 1;
	
	private static final String TYPE_DOC   = "Document";
	private static final String TYPE_LIST  = "DocumentList";
	// --- <<IS-END-SHARED>> ---
}

