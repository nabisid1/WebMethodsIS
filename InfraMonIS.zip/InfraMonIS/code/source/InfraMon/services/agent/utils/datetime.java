package InfraMon.services.agent.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-05-02 10:22:40 MEST
// -----( ON-HOST: localhost

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.text.*;
// --- <<IS-END-IMPORTS>> ---

public final class datetime

{
	// ---( internal utility methods )---

	final static datetime _instance = new datetime();

	static datetime _newInstance() { return new datetime(); }

	static datetime _cast(Object o) { return (datetime)o; }

	// ---( server methods )---




	public static final void quantify (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(quantify)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional timestamp
		// [i] field:0:optional full {"false","true"}
		// [o] field:0:optional duration
		
		IDataCursor pc = pipeline.getCursor();
		
		String timestamp = IDataUtil.getString(pc, "timestamp");
		String full = IDataUtil.getString(pc, "full");
		
		boolean listFull = full != null && full.equals("true");
		
		long ts = 0;
		try {
			ts = Long.parseLong(timestamp);
		} catch (Exception e) {
			ts = Calendar.getInstance().getTime().getTime();
		}
		
		Date date = new Date(ts);
		
		int days = Math.round(ts / 86400000);
		ts = ts % 86400000;
		int hours = Math.round(ts / 3600000);
		ts = ts % 3600000;
		int mins = Math.round(ts / 60000);
		ts = ts % 60000;
		int secs = Math.round(ts / 1000);
		ts = ts % 1000;
		int millis = (int)ts;
		
		StringBuffer buffer = new StringBuffer();
		if (days > 0 || listFull) {
			buffer.append(days).append("d ");
		}
		if (hours > 0 || listFull) {
			buffer.append(hours).append("h ");
		}
		if (mins > 0 || listFull) {
			buffer.append(mins).append("m ");
		}
		if (secs > 0 || listFull) {
			buffer.append(secs).append("s ");
		}
		buffer.append(millis).append("ms ");
		
		IDataUtil.put(pc, "duration", buffer.toString());
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void timer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(timer)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional startTime
		// [o] field:0:optional startTime
		// [o] field:0:optional endTime
		// [o] field:0:optional durationMs
		// [o] field:0:optional durationSec
		IDataCursor pc = pipeline.getCursor();
		String startTime = IDataUtil.getString(pc, "startTime");
		
		// Start timer
		if (startTime == null) {	// start timing
			IDataUtil.put(pc, "startTime", String.valueOf(Calendar.getInstance().getTime().getTime()));
		} else {			// measure
			// Parse start time
			long start = 0;
			if (startTime != null) {
				try {
					start = Long.parseLong(startTime);
				} catch (Exception e) {}
			}
			
			// Get current duration
			long end = Calendar.getInstance().getTime().getTime();
			long durationMs = end - start;
			long durationSec = durationMs / 1000;
			
			IDataUtil.put(pc, "endTime", String.valueOf(end));
			IDataUtil.put(pc, "durationMs", String.valueOf(durationMs));
			IDataUtil.put(pc, "durationSec", String.valueOf(durationSec));
		}
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void timestamp (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(timestamp)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional timestamp
		// [i] field:0:optional datetime
		// [i] field:0:optional format
		// [o] field:0:optional timestamp
		// [o] field:0:optional datetime
		IDataCursor pc = pipeline.getCursor();
		
		String timestamp = IDataUtil.getString(pc, "timestamp");
		String datetime = IDataUtil.getString(pc, "datetime");
		String format = IDataUtil.getString(pc, "format");
		
		boolean override = false;
		if (format == null) {
			format = "dd-MMM-yyyy HH:mm:ss.SSS";
		} else {
			override = true;
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		if (timestamp != null) {
			try {
				datetime = sdf.format(new Date(Long.parseLong(timestamp)));
			} catch (Exception e) {
				throw new ServiceException("Invalid timestamp or format given.");
			}
		} else if (datetime != null) {
			try {
				timestamp = String.valueOf(sdf.parse(datetime).getTime());
			} catch (Exception e) {
				throw new ServiceException("Invalid datetime or format given.");
			}
		} else if (override) {
			Date now = Calendar.getInstance().getTime();
			timestamp = String.valueOf(now.getTime());
			datetime = sdf.format(now);
		}
		
		IDataUtil.put(pc, "timestamp", timestamp);
		IDataUtil.put(pc, "datetime", datetime);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}
}

